package com.nutrifit.app

import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.AutoCompleteTextView
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import kotlin.math.roundToInt

class ManualFoodActivity : AppCompatActivity() {

    private lateinit var etFoodName: AutoCompleteTextView
    private lateinit var etQuantity: EditText
    private lateinit var spinnerUnit: Spinner

    private lateinit var btnCalculateFood: Button
    private lateinit var btnAddFood: Button

    private lateinit var nutritionResultCard: LinearLayout

    private lateinit var tvFoodResult: TextView
    private lateinit var tvFoodCalories: TextView
    private lateinit var tvFoodProtein: TextView
    private lateinit var tvFoodCarbs: TextView
    private lateinit var tvFoodFat: TextView

    private var calculatedCalories = 0.0
    private var calculatedProtein = 0.0
    private var calculatedCarbs = 0.0
    private var calculatedFat = 0.0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_manual_food)

        etFoodName = findViewById(R.id.etFoodName)
        etQuantity = findViewById(R.id.etQuantity)
        spinnerUnit = findViewById(R.id.spinnerUnit)

        btnCalculateFood = findViewById(R.id.btnCalculateFood)
        btnAddFood = findViewById(R.id.btnAddFood)

        nutritionResultCard = findViewById(R.id.nutritionResultCard)

        tvFoodResult = findViewById(R.id.tvFoodResult)
        tvFoodCalories = findViewById(R.id.tvFoodCalories)
        tvFoodProtein = findViewById(R.id.tvFoodProtein)
        tvFoodCarbs = findViewById(R.id.tvFoodCarbs)
        tvFoodFat = findViewById(R.id.tvFoodFat)

        setupFoodSearch()
        setupUnitSpinner()
        handleScannedFood()

        btnCalculateFood.setOnClickListener {
            calculateFood()
        }

        btnAddFood.setOnClickListener {
            addFood()
        }
    }

    /**
     * Handles a food name received from ScannerActivity.
     *
     * If the barcode was successfully matched to a food
     * in BarcodeDatabase, the food name is automatically
     * placed into the food field.
     */
    private fun handleScannedFood() {

        val foodName = intent.getStringExtra("foodName")

        if (!foodName.isNullOrEmpty()) {

            etFoodName.setText(foodName)

            Toast.makeText(
                this,
                "Product recognized: $foodName",
                Toast.LENGTH_SHORT
            ).show()

            etQuantity.requestFocus()
        }
    }

    private fun setupFoodSearch() {

        val foodNames = FoodDatabase.getAllFoods()
            .map { it.name }

        val adapter = ArrayAdapter(
            this,
            android.R.layout.simple_dropdown_item_1line,
            foodNames
        )

        etFoodName.setAdapter(adapter)

        etFoodName.threshold = 1

        etFoodName.setOnItemClickListener { _, _, _, _ ->
            etQuantity.requestFocus()
        }
    }

    private fun setupUnitSpinner() {

        val units = arrayOf(
            "grams (g)",
            "kilograms (kg)",
            "servings"
        )

        val adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_item,
            units
        )

        adapter.setDropDownViewResource(
            android.R.layout.simple_spinner_dropdown_item
        )

        spinnerUnit.adapter = adapter
    }

    private fun calculateFood() {

        val foodName = etFoodName.text.toString().trim()
        val quantityText = etQuantity.text.toString().trim()

        if (foodName.isEmpty()) {
            Toast.makeText(
                this,
                "Please select a food",
                Toast.LENGTH_SHORT
            ).show()
            return
        }

        if (quantityText.isEmpty()) {
            Toast.makeText(
                this,
                "Please enter a quantity",
                Toast.LENGTH_SHORT
            ).show()
            return
        }

        val quantity = quantityText.toDoubleOrNull()

        if (quantity == null || quantity <= 0) {
            Toast.makeText(
                this,
                "Please enter a valid quantity",
                Toast.LENGTH_SHORT
            ).show()
            return
        }

        val food = FoodDatabase.getFood(foodName)

        if (food == null) {
            Toast.makeText(
                this,
                "Please select a food from the suggestions",
                Toast.LENGTH_LONG
            ).show()
            return
        }

        val quantityInGrams = when (spinnerUnit.selectedItemPosition) {

            0 -> quantity

            1 -> quantity * 1000.0

            2 -> quantity * 100.0

            else -> quantity
        }

        val multiplier = quantityInGrams / 100.0

        calculatedCalories =
            food.caloriesPer100g * multiplier

        calculatedProtein =
            food.proteinPer100g * multiplier

        calculatedCarbs =
            food.carbsPer100g * multiplier

        calculatedFat =
            food.fatPer100g * multiplier

        tvFoodResult.text =
            "${food.name} • ${quantityInGrams.roundToInt()} g"

        tvFoodCalories.text =
            "Calories: ${calculatedCalories.roundToInt()} kcal"

        tvFoodProtein.text =
            "Protein: ${calculatedProtein.roundToInt()} g"

        tvFoodCarbs.text =
            "Carbohydrates: ${calculatedCarbs.roundToInt()} g"

        tvFoodFat.text =
            "Fat: ${calculatedFat.roundToInt()} g"

        nutritionResultCard.visibility =
            LinearLayout.VISIBLE
    }

    /**
     * Converts the currently selected quantity into grams.
     * This value is stored in the food history.
     */
    private fun getQuantityInGrams(): Double {

        val quantity =
            etQuantity.text.toString()
                .trim()
                .toDoubleOrNull()
                ?: 0.0

        return when (spinnerUnit.selectedItemPosition) {

            0 -> quantity

            1 -> quantity * 1000.0

            2 -> quantity * 100.0

            else -> quantity
        }
    }

    private fun addFood() {

        if (calculatedCalories <= 0) {
            Toast.makeText(
                this,
                "Calculate the food nutrition first",
                Toast.LENGTH_SHORT
            ).show()
            return
        }

        val foodName = etFoodName.text.toString().trim()
        val quantityInGrams = getQuantityInGrams()

        NutritionTracker.addFood(
            context = this,
            foodName = foodName,
            quantityGrams = quantityInGrams,
            calories = calculatedCalories,
            protein = calculatedProtein,
            carbs = calculatedCarbs,
            fat = calculatedFat
        )

        Toast.makeText(
            this,
            "Food added to today's nutrition!",
            Toast.LENGTH_SHORT
        ).show()

        finish()
    }
}