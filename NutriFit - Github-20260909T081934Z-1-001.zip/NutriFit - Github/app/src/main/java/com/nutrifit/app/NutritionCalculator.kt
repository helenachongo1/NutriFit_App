package com.nutrifit.app

data class NutritionTarget(
    val bmr: Double,
    val tdee: Double,
    val dailyCalories: Double,
    val proteinGrams: Double,
    val carbsGrams: Double,
    val fatGrams: Double
)

object NutritionCalculator {

    fun calculate(
        age: Int,
        gender: String,
        heightCm: Double,
        weightKg: Double,
        activityLevel: String,
        goal: String
    ): NutritionTarget {

        // Mifflin-St Jeor equation
        val bmr = if (gender == "Male") {
            (10 * weightKg) +
                    (6.25 * heightCm) -
                    (5 * age) +
                    5
        } else {
            (10 * weightKg) +
                    (6.25 * heightCm) -
                    (5 * age) -
                    161
        }

        // Activity multiplier
        val activityMultiplier = when (activityLevel) {

            "Sedentary" -> 1.20

            "Lightly Active" -> 1.375

            "Moderately Active" -> 1.55

            "Very Active" -> 1.725

            "Extremely Active" -> 1.90

            else -> 1.20
        }

        val tdee = bmr * activityMultiplier

        // Goal adjustment
        val dailyCalories = when (goal) {

            "Lose Weight" -> tdee - 400

            "Gain Weight" -> tdee + 300

            "Maintain Weight" -> tdee

            else -> tdee
        }

        // Protein target
        // General fitness-oriented estimate:
        // approximately 1.6 g protein per kg body weight.
        val proteinGrams = weightKg * 1.6

        // Fat target: approximately 25% of calories
        val fatCalories = dailyCalories * 0.25
        val fatGrams = fatCalories / 9

        // Remaining calories are assigned to carbohydrates
        val proteinCalories = proteinGrams * 4
        val remainingCalories =
            dailyCalories - proteinCalories - fatCalories

        val carbsGrams = remainingCalories / 4

        return NutritionTarget(
            bmr = bmr,
            tdee = tdee,
            dailyCalories = dailyCalories,
            proteinGrams = proteinGrams,
            carbsGrams = carbsGrams,
            fatGrams = fatGrams
        )
    }
}