package com.nutrifit.app

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import kotlin.math.max
import kotlin.math.roundToInt

class MainActivity : AppCompatActivity() {

    private lateinit var tvCalories: TextView
    private lateinit var tvCaloriesRemaining: TextView
    private lateinit var tvProtein: TextView
    private lateinit var tvCarbs: TextView
    private lateinit var tvFat: TextView

    private lateinit var progressCalories: ProgressBar
    private lateinit var progressProtein: ProgressBar
    private lateinit var progressCarbs: ProgressBar
    private lateinit var progressFat: ProgressBar

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_main)

        // Nutrition text views
        tvCalories = findViewById(R.id.tvCalories)
        tvCaloriesRemaining = findViewById(R.id.tvCaloriesRemaining)
        tvProtein = findViewById(R.id.tvProtein)
        tvCarbs = findViewById(R.id.tvCarbs)
        tvFat = findViewById(R.id.tvFat)

        // Progress bars
        progressCalories = findViewById(R.id.progressCalories)
        progressProtein = findViewById(R.id.progressProtein)
        progressCarbs = findViewById(R.id.progressCarbs)
        progressFat = findViewById(R.id.progressFat)

        // Buttons
        val btnScanFood =
            findViewById<Button>(R.id.btnScanFood)

        val btnManualFood =
            findViewById<Button>(R.id.btnManualFood)

        val btnProfile =
            findViewById<Button>(R.id.btnProfile)

        val btnRecommendations =
            findViewById<Button>(R.id.btnRecommendations)

        val btnHistory =
            findViewById<Button>(R.id.btnHistory)

        // Nutrition card
        val nutritionCard =
            findViewById<LinearLayout>(R.id.nutritionCard)

        // Scan Food
        btnScanFood.setOnClickListener {
            startActivity(
                Intent(
                    this,
                    ScannerActivity::class.java
                )
            )
        }

        // Manual Food
        btnManualFood.setOnClickListener {
            startActivity(
                Intent(
                    this,
                    ManualFoodActivity::class.java
                )
            )
        }

        // Profile
        btnProfile.setOnClickListener {
            startActivity(
                Intent(
                    this,
                    ProfileActivity::class.java
                )
            )
        }

        // Today's Nutrition
        nutritionCard.setOnClickListener {
            startActivity(
                Intent(
                    this,
                    NutritionActivity::class.java
                )
            )
        }

        // Recommendations
        btnRecommendations.setOnClickListener {
            startActivity(
                Intent(
                    this,
                    RecommendationActivity::class.java
                )
            )
        }

        // Food History
        btnHistory.setOnClickListener {
            startActivity(
                Intent(
                    this,
                    FoodHistoryActivity::class.java
                )
            )
        }
    }

    override fun onResume() {
        super.onResume()

        if (::tvCalories.isInitialized) {
            loadNutritionSummary()
        }
    }

    private fun loadNutritionSummary() {

        // Get daily targets from profile
        val preferences =
            getSharedPreferences(
                "NutriFitProfile",
                MODE_PRIVATE
            )

        val calorieTarget =
            preferences.getFloat(
                "dailyCalories",
                0f
            )

        val proteinTarget =
            preferences.getFloat(
                "proteinGrams",
                0f
            )

        val carbsTarget =
            preferences.getFloat(
                "carbsGrams",
                0f
            )

        val fatTarget =
            preferences.getFloat(
                "fatGrams",
                0f
            )

        // Get today's consumed nutrition
        val calories =
            NutritionTracker.getCalories(this)

        val protein =
            NutritionTracker.getProtein(this)

        val carbs =
            NutritionTracker.getCarbs(this)

        val fat =
            NutritionTracker.getFat(this)

        // Calculate remaining calories
        val remainingCalories =
            max(
                0f,
                calorieTarget - calories
            )

        // Update text
        tvCalories.text =
            "Calories: ${calories.roundToInt()} / " +
                    "${calorieTarget.roundToInt()} kcal"

        tvCaloriesRemaining.text =
            "Remaining: " +
                    "${remainingCalories.roundToInt()} kcal"

        tvProtein.text =
            "Protein: ${protein.roundToInt()} / " +
                    "${proteinTarget.roundToInt()} g"

        tvCarbs.text =
            "Carbs: ${carbs.roundToInt()} / " +
                    "${carbsTarget.roundToInt()} g"

        tvFat.text =
            "Fat: ${fat.roundToInt()} / " +
                    "${fatTarget.roundToInt()} g"

        // Update progress bars
        progressCalories.progress =
            calculateProgress(
                calories,
                calorieTarget
            )

        progressProtein.progress =
            calculateProgress(
                protein,
                proteinTarget
            )

        progressCarbs.progress =
            calculateProgress(
                carbs,
                carbsTarget
            )

        progressFat.progress =
            calculateProgress(
                fat,
                fatTarget
            )
    }

    private fun calculateProgress(
        consumed: Float,
        target: Float
    ): Int {

        if (target <= 0f) {
            return 0
        }

        return (
                (consumed / target) * 100
                )
            .roundToInt()
            .coerceIn(0, 100)
    }
}