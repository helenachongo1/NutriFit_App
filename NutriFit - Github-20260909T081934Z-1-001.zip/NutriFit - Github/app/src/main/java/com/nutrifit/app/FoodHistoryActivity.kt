package com.nutrifit.app

import android.app.AlertDialog
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class FoodHistoryActivity : AppCompatActivity() {

    private lateinit var historyContainer: LinearLayout

    private lateinit var tvTotalCalories: TextView
    private lateinit var tvTotalProtein: TextView
    private lateinit var tvTotalCarbs: TextView
    private lateinit var tvTotalFat: TextView

    private val dateFormat =
        SimpleDateFormat(
            "dd MMM yyyy, hh:mm a",
            Locale.getDefault()
        )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(
            R.layout.activity_food_history
        )

        historyContainer =
            findViewById(R.id.historyContainer)

        tvTotalCalories =
            findViewById(R.id.tvTotalCalories)

        tvTotalProtein =
            findViewById(R.id.tvTotalProtein)

        tvTotalCarbs =
            findViewById(R.id.tvTotalCarbs)

        tvTotalFat =
            findViewById(R.id.tvTotalFat)

        val btnClearHistory =
            findViewById<Button>(
                R.id.btnClearHistory
            )

        btnClearHistory.setOnClickListener {

            showClearHistoryConfirmation()
        }

        loadHistory()
    }

    override fun onResume() {
        super.onResume()

        if (::historyContainer.isInitialized) {
            loadHistory()
        }
    }

    private fun loadHistory() {

        historyContainer.removeAllViews()

        updateTodaySummary()

        val history =
            NutritionTracker.getHistory(this)

        if (history.isEmpty()) {

            val emptyText =
                TextView(this)

            emptyText.text =
                "No food history yet.\n\n" +
                        "Foods you add will appear here."

            emptyText.textSize = 17f

            emptyText.setTextColor(
                getColor(
                    R.color.nutrifit_text_secondary
                )
            )

            emptyText.gravity =
                Gravity.CENTER

            emptyText.setPadding(
                20,
                50,
                20,
                50
            )

            historyContainer.addView(
                emptyText
            )

            return
        }

        history.forEach { entry ->

            addHistoryCard(entry)
        }
    }

    /**
     * Updates the Today's Total card using
     * the same daily nutrition data displayed
     * throughout the NutriFit application.
     */
    private fun updateTodaySummary() {

        val calories =
            NutritionTracker.getCalories(this)

        val protein =
            NutritionTracker.getProtein(this)

        val carbs =
            NutritionTracker.getCarbs(this)

        val fat =
            NutritionTracker.getFat(this)

        tvTotalCalories.text =
            "${calories.toInt()} kcal"

        tvTotalProtein.text =
            "Protein: ${protein.toInt()} g"

        tvTotalCarbs.text =
            "Carbs: ${carbs.toInt()} g"

        tvTotalFat.text =
            "Fat: ${fat.toInt()} g"
    }

    private fun addHistoryCard(
        entry: FoodHistoryEntry
    ) {

        val card =
            LinearLayout(this)

        card.orientation =
            LinearLayout.VERTICAL

        card.setPadding(
            20,
            18,
            20,
            18
        )

        card.setBackgroundColor(
            getColor(
                R.color.nutrifit_surface
            )
        )

        val cardParams =
            LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )

        cardParams.setMargins(
            0,
            0,
            0,
            14
        )

        card.layoutParams =
            cardParams

        // Food name

        val foodName =
            TextView(this)

        foodName.text =
            entry.foodName

        foodName.textSize =
            20f

        foodName.setTextColor(
            getColor(
                R.color.nutrifit_text
            )
        )

        foodName.setTypeface(
            null,
            Typeface.BOLD
        )

        // Quantity and date

        val details =
            TextView(this)

        details.text =
            "${entry.quantityGrams.toInt()} g • " +
                    dateFormat.format(
                        Date(entry.timestamp)
                    )

        details.textSize =
            14f

        details.setTextColor(
            getColor(
                R.color.nutrifit_text_secondary
            )
        )

        details.setPadding(
            0,
            6,
            0,
            10
        )

        // Calories

        val calories =
            TextView(this)

        calories.text =
            "Calories: ${entry.calories.toInt()} kcal"

        calories.textSize =
            16f

        calories.setTextColor(
            getColor(
                R.color.nutrifit_text
            )
        )

        // Macronutrients

        val macros =
            TextView(this)

        macros.text =
            "Protein: ${entry.protein.toInt()} g   •   " +
                    "Carbs: ${entry.carbs.toInt()} g   •   " +
                    "Fat: ${entry.fat.toInt()} g"

        macros.textSize =
            15f

        macros.setTextColor(
            getColor(
                R.color.nutrifit_text_secondary
            )
        )

        card.addView(foodName)
        card.addView(details)
        card.addView(calories)
        card.addView(macros)

        historyContainer.addView(
            card
        )
    }

    private fun showClearHistoryConfirmation() {

        AlertDialog.Builder(this)
            .setTitle("Clear Food History?")
            .setMessage(
                "This will permanently remove all " +
                        "logged food history."
            )
            .setNegativeButton(
                "Cancel",
                null
            )
            .setPositiveButton(
                "Clear"
            ) { _, _ ->

                NutritionTracker.clearHistory(
                    this
                )

                loadHistory()
            }
            .show()
    }
}