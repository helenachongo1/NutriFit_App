package com.nutrifit.app

import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.Spinner
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class ProfileActivity : AppCompatActivity() {

    private lateinit var etAge: EditText
    private lateinit var etHeight: EditText
    private lateinit var etWeight: EditText

    private lateinit var spinnerGender: Spinner
    private lateinit var spinnerActivity: Spinner
    private lateinit var spinnerGoal: Spinner

    private lateinit var btnSaveProfile: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profile)

        etAge = findViewById(R.id.etAge)
        etHeight = findViewById(R.id.etHeight)
        etWeight = findViewById(R.id.etWeight)

        spinnerGender = findViewById(R.id.spinnerGender)
        spinnerActivity = findViewById(R.id.spinnerActivity)
        spinnerGoal = findViewById(R.id.spinnerGoal)

        btnSaveProfile = findViewById(R.id.btnSaveProfile)

        setupSpinners()
        loadProfile()

        btnSaveProfile.setOnClickListener {
            saveProfile()
        }
    }

    private fun setupSpinners() {

        val genders = arrayOf(
            "Select Gender",
            "Male",
            "Female"
        )

        val activityLevels = arrayOf(
            "Select Activity Level",
            "Sedentary",
            "Lightly Active",
            "Moderately Active",
            "Very Active",
            "Extremely Active"
        )

        val goals = arrayOf(
            "Select Fitness Goal",
            "Lose Weight",
            "Maintain Weight",
            "Gain Weight"
        )

        spinnerGender.adapter = createAdapter(genders)
        spinnerActivity.adapter = createAdapter(activityLevels)
        spinnerGoal.adapter = createAdapter(goals)
    }

    private fun createAdapter(items: Array<String>): ArrayAdapter<String> {

        return ArrayAdapter(
            this,
            android.R.layout.simple_spinner_item,
            items
        ).apply {
            setDropDownViewResource(
                android.R.layout.simple_spinner_dropdown_item
            )
        }
    }

    private fun saveProfile() {

        val ageText = etAge.text.toString().trim()
        val heightText = etHeight.text.toString().trim()
        val weightText = etWeight.text.toString().trim()

        // Check required numerical fields
        if (ageText.isEmpty() ||
            heightText.isEmpty() ||
            weightText.isEmpty()
        ) {
            Toast.makeText(
                this,
                "Please enter age, height and weight",
                Toast.LENGTH_SHORT
            ).show()
            return
        }

        // Check dropdown selections
        if (spinnerGender.selectedItemPosition == 0 ||
            spinnerActivity.selectedItemPosition == 0 ||
            spinnerGoal.selectedItemPosition == 0
        ) {
            Toast.makeText(
                this,
                "Please select all profile options",
                Toast.LENGTH_SHORT
            ).show()
            return
        }

        val age = ageText.toIntOrNull()
        val height = heightText.toFloatOrNull()
        val weight = weightText.toFloatOrNull()

        // Check valid numbers
        if (age == null || height == null || weight == null) {
            Toast.makeText(
                this,
                "Please enter valid numbers",
                Toast.LENGTH_SHORT
            ).show()
            return
        }

        // Validate age
        if (age !in 13..100) {
            Toast.makeText(
                this,
                "Please enter an age between 13 and 100",
                Toast.LENGTH_SHORT
            ).show()
            return
        }

        // Validate height
        if (height <= 50 || height >= 250) {
            Toast.makeText(
                this,
                "Please enter a valid height",
                Toast.LENGTH_SHORT
            ).show()
            return
        }

        // Validate weight
        if (weight <= 20 || weight >= 300) {
            Toast.makeText(
                this,
                "Please enter a valid weight",
                Toast.LENGTH_SHORT
            ).show()
            return
        }

        // -------------------------------------------------
        // SAVE PROFILE
        // -------------------------------------------------

        val preferences = getSharedPreferences(
            "NutriFitProfile",
            MODE_PRIVATE
        )

        preferences.edit()
            .putInt("age", age)
            .putFloat("height", height)
            .putFloat("weight", weight)
            .putString(
                "gender",
                spinnerGender.selectedItem.toString()
            )
            .putString(
                "activity",
                spinnerActivity.selectedItem.toString()
            )
            .putString(
                "goal",
                spinnerGoal.selectedItem.toString()
            )
            .apply()

        // -------------------------------------------------
        // CALCULATE NUTRITION TARGETS
        // -------------------------------------------------

        val nutritionTarget = NutritionCalculator.calculate(
            age = age,
            gender = spinnerGender.selectedItem.toString(),
            heightCm = height.toDouble(),
            weightKg = weight.toDouble(),
            activityLevel = spinnerActivity.selectedItem.toString(),
            goal = spinnerGoal.selectedItem.toString()
        )

        // -------------------------------------------------
        // SAVE NUTRITION TARGETS
        // -------------------------------------------------

        preferences.edit()
            .putFloat(
                "dailyCalories",
                nutritionTarget.dailyCalories.toFloat()
            )
            .putFloat(
                "proteinGrams",
                nutritionTarget.proteinGrams.toFloat()
            )
            .putFloat(
                "carbsGrams",
                nutritionTarget.carbsGrams.toFloat()
            )
            .putFloat(
                "fatGrams",
                nutritionTarget.fatGrams.toFloat()
            )
            .putFloat(
                "bmr",
                nutritionTarget.bmr.toFloat()
            )
            .putFloat(
                "tdee",
                nutritionTarget.tdee.toFloat()
            )
            .apply()

        Toast.makeText(
            this,
            "Profile and nutrition targets saved!",
            Toast.LENGTH_SHORT
        ).show()

        finish()
    }

    private fun loadProfile() {

        val preferences = getSharedPreferences(
            "NutriFitProfile",
            MODE_PRIVATE
        )

        // No saved profile yet
        if (!preferences.contains("age")) {
            return
        }

        etAge.setText(
            preferences.getInt("age", 0).toString()
        )

        etHeight.setText(
            preferences.getFloat("height", 0f).toString()
        )

        etWeight.setText(
            preferences.getFloat("weight", 0f).toString()
        )

        setSpinnerSelection(
            spinnerGender,
            preferences.getString("gender", "")
        )

        setSpinnerSelection(
            spinnerActivity,
            preferences.getString("activity", "")
        )

        setSpinnerSelection(
            spinnerGoal,
            preferences.getString("goal", "")
        )
    }

    private fun setSpinnerSelection(
        spinner: Spinner,
        value: String?
    ) {

        if (value == null) {
            return
        }

        val adapter = spinner.adapter

        for (i in 0 until adapter.count) {

            if (adapter.getItem(i).toString() == value) {
                spinner.setSelection(i)
                break
            }
        }
    }
}