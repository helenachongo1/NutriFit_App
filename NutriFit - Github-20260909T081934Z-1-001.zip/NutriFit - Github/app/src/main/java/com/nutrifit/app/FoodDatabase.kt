package com.nutrifit.app

object FoodDatabase {

    private val foods = listOf(

        // =========================================================
        // PROTEINS
        // =========================================================

        Food(
            name = "Chicken Breast",
            aliases = listOf(
                "chicken",
                "chicken breast",
                "chicken fillet",
                "chicken filet"
            ),
            category = "Protein",
            caloriesPer100g = 165.0,
            proteinPer100g = 31.0,
            carbsPer100g = 0.0,
            fatPer100g = 3.6,
            servingSize = 150.0,
            servingUnit = "g",
            preparationMethods = listOf(
                "grilled",
                "baked",
                "boiled",
                "pan-fried"
            ),
            highProtein = true,
            lowCalorie = true,
            mealTypes = listOf(
                "Lunch",
                "Dinner"
            ),
            cuisines = listOf(
                "African",
                "Indian",
                "Asian",
                "Western"
            )
        ),

        Food(
            name = "Chicken Thigh",
            aliases = listOf(
                "chicken thigh"
            ),
            category = "Protein",
            caloriesPer100g = 209.0,
            proteinPer100g = 26.0,
            carbsPer100g = 0.0,
            fatPer100g = 10.9,
            servingSize = 150.0,
            servingUnit = "g",
            preparationMethods = listOf(
                "grilled",
                "baked",
                "roasted"
            ),
            highProtein = true,
            mealTypes = listOf(
                "Lunch",
                "Dinner"
            ),
            cuisines = listOf(
                "African",
                "Indian",
                "Asian",
                "Western"
            )
        ),

        Food(
            name = "Chicken Drumstick",
            aliases = listOf(
                "chicken leg",
                "drumstick"
            ),
            category = "Protein",
            caloriesPer100g = 172.0,
            proteinPer100g = 28.0,
            carbsPer100g = 0.0,
            fatPer100g = 5.7,
            servingSize = 150.0,
            servingUnit = "g",
            preparationMethods = listOf(
                "grilled",
                "baked",
                "roasted"
            ),
            highProtein = true,
            mealTypes = listOf(
                "Lunch",
                "Dinner"
            ),
            cuisines = listOf(
                "African",
                "Indian",
                "Western"
            )
        ),

        Food(
            name = "Lean Beef",
            aliases = listOf(
                "beef",
                "lean beef"
            ),
            category = "Protein",
            caloriesPer100g = 172.0,
            proteinPer100g = 26.0,
            carbsPer100g = 0.0,
            fatPer100g = 7.0,
            servingSize = 150.0,
            servingUnit = "g",
            preparationMethods = listOf(
                "grilled",
                "stir-fried",
                "pan-fried"
            ),
            highProtein = true,
            mealTypes = listOf(
                "Lunch",
                "Dinner"
            ),
            cuisines = listOf(
                "African",
                "Indian",
                "Asian",
                "Western"
            )
        ),

        Food(
            name = "Goat Meat",
            aliases = listOf(
                "goat",
                "goat meat"
            ),
            category = "Protein",
            caloriesPer100g = 143.0,
            proteinPer100g = 27.1,
            carbsPer100g = 0.0,
            fatPer100g = 3.0,
            servingSize = 150.0,
            servingUnit = "g",
            preparationMethods = listOf(
                "stewed",
                "grilled",
                "roasted"
            ),
            highProtein = true,
            lowCalorie = true,
            mealTypes = listOf(
                "Lunch",
                "Dinner"
            ),
            cuisines = listOf(
                "African",
                "Indian"
            )
        ),

        Food(
            name = "Tuna",
            aliases = listOf(
                "tuna fish",
                "canned tuna"
            ),
            category = "Protein",
            caloriesPer100g = 132.0,
            proteinPer100g = 28.0,
            carbsPer100g = 0.0,
            fatPer100g = 1.3,
            servingSize = 120.0,
            servingUnit = "g",
            preparationMethods = listOf(
                "mixed",
                "grilled",
                "salad"
            ),
            highProtein = true,
            lowCalorie = true,
            mealTypes = listOf(
                "Lunch",
                "Dinner"
            ),
            cuisines = listOf(
                "Asian",
                "Western"
            )
        ),

        Food(
            name = "Salmon",
            aliases = listOf(
                "salmon fish"
            ),
            category = "Protein",
            caloriesPer100g = 208.0,
            proteinPer100g = 20.0,
            carbsPer100g = 0.0,
            fatPer100g = 13.0,
            servingSize = 150.0,
            servingUnit = "g",
            preparationMethods = listOf(
                "grilled",
                "baked",
                "pan-fried"
            ),
            highProtein = true,
            mealTypes = listOf(
                "Lunch",
                "Dinner"
            ),
            cuisines = listOf(
                "Western",
                "Asian"
            )
        ),

        Food(
            name = "Sardines",
            aliases = listOf(
                "sardine",
                "sardine fish"
            ),
            category = "Protein",
            caloriesPer100g = 208.0,
            proteinPer100g = 24.6,
            carbsPer100g = 0.0,
            fatPer100g = 11.5,
            servingSize = 100.0,
            servingUnit = "g",
            preparationMethods = listOf(
                "grilled",
                "baked",
                "pan-fried"
            ),
            highProtein = true,
            mealTypes = listOf(
                "Lunch",
                "Dinner"
            ),
            cuisines = listOf(
                "African",
                "Mediterranean"
            )
        ),

        Food(
            name = "Tilapia",
            aliases = listOf(
                "tilapia fish"
            ),
            category = "Protein",
            caloriesPer100g = 128.0,
            proteinPer100g = 26.0,
            carbsPer100g = 0.0,
            fatPer100g = 2.7,
            servingSize = 150.0,
            servingUnit = "g",
            preparationMethods = listOf(
                "grilled",
                "baked",
                "steamed"
            ),
            highProtein = true,
            lowCalorie = true,
            mealTypes = listOf(
                "Lunch",
                "Dinner"
            ),
            cuisines = listOf(
                "African",
                "Indian",
                "Asian"
            )
        ),

        Food(
            name = "Shrimp",
            aliases = listOf(
                "prawns",
                "prawn",
                "shrimp"
            ),
            category = "Protein",
            caloriesPer100g = 99.0,
            proteinPer100g = 24.0,
            carbsPer100g = 0.2,
            fatPer100g = 0.3,
            servingSize = 120.0,
            servingUnit = "g",
            preparationMethods = listOf(
                "grilled",
                "stir-fried",
                "boiled"
            ),
            highProtein = true,
            lowCalorie = true,
            mealTypes = listOf(
                "Lunch",
                "Dinner"
            ),
            cuisines = listOf(
                "Asian",
                "African"
            )
        ),

        Food(
            name = "Egg",
            aliases = listOf(
                "eggs",
                "egg",
                "boiled egg"
            ),
            category = "Protein",
            caloriesPer100g = 143.0,
            proteinPer100g = 12.6,
            carbsPer100g = 0.7,
            fatPer100g = 9.5,
            servingSize = 50.0,
            servingUnit = "1 egg",
            preparationMethods = listOf(
                "boiled",
                "scrambled",
                "fried",
                "poached",
                "omelette"
            ),
            highProtein = true,
            vegetarian = true,
            mealTypes = listOf(
                "Breakfast",
                "Lunch",
                "Dinner",
                "Snack"
            ),
            cuisines = listOf(
                "African",
                "Indian",
                "Asian",
                "Western"
            )
        ),

        Food(
            name = "Egg White",
            aliases = listOf(
                "egg whites",
                "egg white"
            ),
            category = "Protein",
            caloriesPer100g = 52.0,
            proteinPer100g = 10.9,
            carbsPer100g = 0.7,
            fatPer100g = 0.2,
            servingSize = 30.0,
            servingUnit = "1 egg white",
            preparationMethods = listOf(
                "scrambled",
                "boiled",
                "omelette"
            ),
            highProtein = true,
            lowCalorie = true,
            vegetarian = true,
            mealTypes = listOf(
                "Breakfast",
                "Snack"
            ),
            cuisines = listOf(
                "Universal"
            )
        ),

        Food(
            name = "Tofu",
            aliases = listOf(
                "bean curd",
                "tofu"
            ),
            category = "Protein",
            caloriesPer100g = 76.0,
            proteinPer100g = 8.0,
            carbsPer100g = 1.9,
            fatPer100g = 4.8,
            servingSize = 150.0,
            servingUnit = "g",
            preparationMethods = listOf(
                "stir-fried",
                "grilled",
                "baked"
            ),
            highProtein = true,
            vegetarian = true,
            vegan = true,
            mealTypes = listOf(
                "Lunch",
                "Dinner"
            ),
            cuisines = listOf(
                "Asian",
                "Indian"
            )
        ),

        // =========================================================
        // GRAINS & CARBOHYDRATES
        // =========================================================

        Food(
            name = "Rice",
            aliases = listOf(
                "white rice",
                "cooked rice",
                "rice"
            ),
            category = "Carbohydrate",
            caloriesPer100g = 130.0,
            proteinPer100g = 2.7,
            carbsPer100g = 28.2,
            fatPer100g = 0.3,
            servingSize = 150.0,
            servingUnit = "g",
            preparationMethods = listOf(
                "boiled",
                "steamed"
            ),
            vegetarian = true,
            vegan = true,
            mealTypes = listOf(
                "Lunch",
                "Dinner"
            ),
            cuisines = listOf(
                "African",
                "Indian",
                "Asian",
                "Universal"
            )
        ),

        Food(
            name = "Brown Rice",
            aliases = listOf(
                "brown rice"
            ),
            category = "Carbohydrate",
            caloriesPer100g = 123.0,
            proteinPer100g = 2.7,
            carbsPer100g = 25.6,
            fatPer100g = 1.0,
            servingSize = 150.0,
            servingUnit = "g",
            preparationMethods = listOf(
                "boiled",
                "steamed"
            ),
            vegetarian = true,
            vegan = true,
            mealTypes = listOf(
                "Lunch",
                "Dinner"
            ),
            cuisines = listOf(
                "African",
                "Indian",
                "Asian"
            )
        ),

        Food(
            name = "Basmati Rice",
            aliases = listOf(
                "basmati",
                "basmati rice"
            ),
            category = "Carbohydrate",
            caloriesPer100g = 130.0,
            proteinPer100g = 2.7,
            carbsPer100g = 28.0,
            fatPer100g = 0.3,
            servingSize = 150.0,
            servingUnit = "g",
            preparationMethods = listOf(
                "boiled",
                "steamed"
            ),
            vegetarian = true,
            vegan = true,
            mealTypes = listOf(
                "Lunch",
                "Dinner"
            ),
            cuisines = listOf(
                "Indian",
                "Asian"
            )
        ),

        Food(
            name = "Oats",
            aliases = listOf(
                "oatmeal",
                "rolled oats",
                "oats"
            ),
            category = "Carbohydrate",
            caloriesPer100g = 389.0,
            proteinPer100g = 16.9,
            carbsPer100g = 66.3,
            fatPer100g = 6.9,
            servingSize = 40.0,
            servingUnit = "g",
            preparationMethods = listOf(
                "cooked",
                "overnight oats"
            ),
            vegetarian = true,
            vegan = true,
            mealTypes = listOf(
                "Breakfast",
                "Snack"
            ),
            cuisines = listOf(
                "Universal"
            )
        ),

        Food(
            name = "Pasta",
            aliases = listOf(
                "pasta",
                "spaghetti"
            ),
            category = "Carbohydrate",
            caloriesPer100g = 158.0,
            proteinPer100g = 5.8,
            carbsPer100g = 30.9,
            fatPer100g = 0.9,
            servingSize = 180.0,
            servingUnit = "g",
            preparationMethods = listOf(
                "boiled"
            ),
            vegetarian = true,
            vegan = true,
            mealTypes = listOf(
                "Lunch",
                "Dinner"
            ),
            cuisines = listOf(
                "Western",
                "Indian"
            )
        ),

        Food(
            name = "Whole Wheat Bread",
            aliases = listOf(
                "whole wheat bread",
                "brown bread",
                "whole grain bread"
            ),
            category = "Carbohydrate",
            caloriesPer100g = 247.0,
            proteinPer100g = 13.0,
            carbsPer100g = 41.0,
            fatPer100g = 4.2,
            servingSize = 30.0,
            servingUnit = "1 slice",
            preparationMethods = listOf(
                "toasted",
                "fresh"
            ),
            vegetarian = true,
            vegan = true,
            mealTypes = listOf(
                "Breakfast",
                "Lunch",
                "Snack"
            ),
            cuisines = listOf(
                "Universal"
            )
        ),

        Food(
            name = "Chapati",
            aliases = listOf(
                "chapati",
                "roti",
                "roti bread"
            ),
            category = "Carbohydrate",
            caloriesPer100g = 297.0,
            proteinPer100g = 11.0,
            carbsPer100g = 55.0,
            fatPer100g = 5.0,
            servingSize = 40.0,
            servingUnit = "1 chapati",
            preparationMethods = listOf(
                "pan-cooked"
            ),
            vegetarian = true,
            vegan = true,
            mealTypes = listOf(
                "Breakfast",
                "Lunch",
                "Dinner"
            ),
            cuisines = listOf(
                "Indian",
                "African"
            )
        ),

        Food(
            name = "Potato",
            aliases = listOf(
                "potatoes",
                "potato"
            ),
            category = "Carbohydrate",
            caloriesPer100g = 87.0,
            proteinPer100g = 1.9,
            carbsPer100g = 20.1,
            fatPer100g = 0.1,
            servingSize = 150.0,
            servingUnit = "g",
            preparationMethods = listOf(
                "boiled",
                "baked",
                "mashed"
            ),
            vegetarian = true,
            vegan = true,
            mealTypes = listOf(
                "Lunch",
                "Dinner"
            ),
            cuisines = listOf(
                "African",
                "Indian",
                "Western"
            )
        ),

        Food(
            name = "Sweet Potato",
            aliases = listOf(
                "sweet potato",
                "sweet potatoes"
            ),
            category = "Carbohydrate",
            caloriesPer100g = 86.0,
            proteinPer100g = 1.6,
            carbsPer100g = 20.1,
            fatPer100g = 0.1,
            servingSize = 150.0,
            servingUnit = "g",
            preparationMethods = listOf(
                "boiled",
                "baked",
                "roasted"
            ),
            vegetarian = true,
            vegan = true,
            mealTypes = listOf(
                "Breakfast",
                "Lunch",
                "Dinner"
            ),
            cuisines = listOf(
                "African",
                "Indian"
            )
        ),

        Food(
            name = "Cassava",
            aliases = listOf(
                "cassava",
                "manioc",
                "yuca"
            ),
            category = "Carbohydrate",
            caloriesPer100g = 160.0,
            proteinPer100g = 1.4,
            carbsPer100g = 38.0,
            fatPer100g = 0.3,
            servingSize = 150.0,
            servingUnit = "g",
            preparationMethods = listOf(
                "boiled",
                "steamed",
                "baked"
            ),
            vegetarian = true,
            vegan = true,
            mealTypes = listOf(
                "Lunch",
                "Dinner"
            ),
            cuisines = listOf(
                "African"
            )
        ),

        Food(
            name = "Maize",
            aliases = listOf(
                "maize",
                "corn",
                "sweet corn"
            ),
            category = "Carbohydrate",
            caloriesPer100g = 96.0,
            proteinPer100g = 3.4,
            carbsPer100g = 21.0,
            fatPer100g = 1.5,
            servingSize = 150.0,
            servingUnit = "g",
            preparationMethods = listOf(
                "boiled",
                "grilled",
                "steamed"
            ),
            vegetarian = true,
            vegan = true,
            mealTypes = listOf(
                "Lunch",
                "Dinner",
                "Snack"
            ),
            cuisines = listOf(
                "African",
                "Indian",
                "Asian"
            )
        ),

        Food(
            name = "Quinoa",
            aliases = listOf(
                "quinoa"
            ),
            category = "Carbohydrate",
            caloriesPer100g = 120.0,
            proteinPer100g = 4.4,
            carbsPer100g = 21.3,
            fatPer100g = 1.9,
            servingSize = 150.0,
            servingUnit = "g",
            preparationMethods = listOf(
                "boiled",
                "steamed"
            ),
            vegetarian = true,
            vegan = true,
            mealTypes = listOf(
                "Lunch",
                "Dinner"
            ),
            cuisines = listOf(
                "Universal"
            )
        ),

        Food(
            name = "Plantain",
            aliases = listOf(
                "plantain",
                "plantains"
            ),
            category = "Carbohydrate",
            caloriesPer100g = 122.0,
            proteinPer100g = 1.3,
            carbsPer100g = 31.9,
            fatPer100g = 0.4,
            servingSize = 150.0,
            servingUnit = "g",
            preparationMethods = listOf(
                "boiled",
                "baked",
                "grilled"
            ),
            vegetarian = true,
            vegan = true,
            mealTypes = listOf(
                "Lunch",
                "Dinner"
            ),
            cuisines = listOf(
                "African"
            )
        ),

        // =========================================================
        // LEGUMES
        // =========================================================

        Food(
            name = "Lentils",
            aliases = listOf(
                "lentil",
                "dal",
                "dhal"
            ),
            category = "Legume",
            caloriesPer100g = 116.0,
            proteinPer100g = 9.0,
            carbsPer100g = 20.1,
            fatPer100g = 0.4,
            servingSize = 150.0,
            servingUnit = "g",
            preparationMethods = listOf(
                "boiled",
                "stewed"
            ),
            highProtein = true,
            vegetarian = true,
            vegan = true,
            mealTypes = listOf(
                "Lunch",
                "Dinner"
            ),
            cuisines = listOf(
                "Indian",
                "African"
            )
        ),

        Food(
            name = "Chickpeas",
            aliases = listOf(
                "chickpea",
                "garbanzo beans"
            ),
            category = "Legume",
            caloriesPer100g = 164.0,
            proteinPer100g = 8.9,
            carbsPer100g = 27.4,
            fatPer100g = 2.6,
            servingSize = 150.0,
            servingUnit = "g",
            preparationMethods = listOf(
                "boiled",
                "roasted",
                "stewed"
            ),
            highProtein = true,
            vegetarian = true,
            vegan = true,
            mealTypes = listOf(
                "Lunch",
                "Dinner",
                "Snack"
            ),
            cuisines = listOf(
                "Indian",
                "African",
                "Mediterranean"
            )
        ),

        Food(
            name = "Kidney Beans",
            aliases = listOf(
                "kidney bean",
                "red beans"
            ),
            category = "Legume",
            caloriesPer100g = 127.0,
            proteinPer100g = 8.7,
            carbsPer100g = 22.8,
            fatPer100g = 0.5,
            servingSize = 150.0,
            servingUnit = "g",
            preparationMethods = listOf(
                "boiled",
                "stewed"
            ),
            highProtein = true,
            vegetarian = true,
            vegan = true,
            mealTypes = listOf(
                "Lunch",
                "Dinner"
            ),
            cuisines = listOf(
                "African",
                "Indian",
                "Western"
            )
        ),

        Food(
            name = "Black Beans",
            aliases = listOf(
                "black bean",
                "black beans"
            ),
            category = "Legume",
            caloriesPer100g = 132.0,
            proteinPer100g = 8.9,
            carbsPer100g = 23.7,
            fatPer100g = 0.5,
            servingSize = 150.0,
            servingUnit = "g",
            preparationMethods = listOf(
                "boiled",
                "stewed"
            ),
            highProtein = true,
            vegetarian = true,
            vegan = true,
            mealTypes = listOf(
                "Lunch",
                "Dinner"
            ),
            cuisines = listOf(
                "African",
                "Western"
            )
        ),

        Food(
            name = "Green Peas",
            aliases = listOf(
                "peas",
                "green peas"
            ),
            category = "Legume",
            caloriesPer100g = 84.0,
            proteinPer100g = 5.4,
            carbsPer100g = 15.6,
            fatPer100g = 0.4,
            servingSize = 100.0,
            servingUnit = "g",
            preparationMethods = listOf(
                "boiled",
                "steamed"
            ),
            vegetarian = true,
            vegan = true,
            mealTypes = listOf(
                "Lunch",
                "Dinner"
            ),
            cuisines = listOf(
                "African",
                "Indian",
                "Western"
            )
        ),

        // =========================================================
        // VEGETABLES
        // =========================================================

        Food(
            name = "Tomato",
            aliases = listOf(
                "tomato",
                "tomatoes"
            ),
            category = "Vegetable",
            caloriesPer100g = 18.0,
            proteinPer100g = 0.9,
            carbsPer100g = 3.9,
            fatPer100g = 0.2,
            servingSize = 100.0,
            servingUnit = "g",
            preparationMethods = listOf(
                "raw",
                "sautéed",
                "stewed"
            ),
            lowCalorie = true,
            vegetarian = true,
            vegan = true,
            mealTypes = listOf(
                "Breakfast",
                "Lunch",
                "Dinner"
            ),
            cuisines = listOf(
                "African",
                "Indian",
                "Asian",
                "Western"
            )
        ),

        Food(
            name = "Onion",
            aliases = listOf(
                "onion",
                "onions"
            ),
            category = "Vegetable",
            caloriesPer100g = 40.0,
            proteinPer100g = 1.1,
            carbsPer100g = 9.3,
            fatPer100g = 0.1,
            servingSize = 50.0,
            servingUnit = "g",
            preparationMethods = listOf(
                "raw",
                "sautéed",
                "fried"
            ),
            vegetarian = true,
            vegan = true,
            mealTypes = listOf(
                "Breakfast",
                "Lunch",
                "Dinner"
            ),
            cuisines = listOf(
                "African",
                "Indian",
                "Asian",
                "Western"
            )
        ),

        Food(
            name = "Spinach",
            aliases = listOf(
                "spinach"
            ),
            category = "Vegetable",
            caloriesPer100g = 23.0,
            proteinPer100g = 2.9,
            carbsPer100g = 3.6,
            fatPer100g = 0.4,
            servingSize = 100.0,
            servingUnit = "g",
            preparationMethods = listOf(
                "raw",
                "steamed",
                "sautéed"
            ),
            lowCalorie = true,
            vegetarian = true,
            vegan = true,
            mealTypes = listOf(
                "Breakfast",
                "Lunch",
                "Dinner"
            ),
            cuisines = listOf(
                "African",
                "Indian",
                "Western"
            )
        ),

        Food(
            name = "Broccoli",
            aliases = listOf(
                "broccoli"
            ),
            category = "Vegetable",
            caloriesPer100g = 35.0,
            proteinPer100g = 2.4,
            carbsPer100g = 7.2,
            fatPer100g = 0.4,
            servingSize = 100.0,
            servingUnit = "g",
            preparationMethods = listOf(
                "steamed",
                "roasted",
                "sautéed"
            ),
            lowCalorie = true,
            vegetarian = true,
            vegan = true,
            mealTypes = listOf(
                "Lunch",
                "Dinner"
            ),
            cuisines = listOf(
                "Universal"
            )
        ),

        Food(
            name = "Cabbage",
            aliases = listOf(
                "cabbage"
            ),
            category = "Vegetable",
            caloriesPer100g = 25.0,
            proteinPer100g = 1.3,
            carbsPer100g = 5.8,
            fatPer100g = 0.1,
            servingSize = 100.0,
            servingUnit = "g",
            preparationMethods = listOf(
                "raw",
                "steamed",
                "sautéed"
            ),
            lowCalorie = true,
            vegetarian = true,
            vegan = true,
            mealTypes = listOf(
                "Lunch",
                "Dinner"
            ),
            cuisines = listOf(
                "African",
                "Indian",
                "Western"
            )
        ),

        Food(
            name = "Carrot",
            aliases = listOf(
                "carrot",
                "carrots"
            ),
            category = "Vegetable",
            caloriesPer100g = 41.0,
            proteinPer100g = 0.9,
            carbsPer100g = 9.6,
            fatPer100g = 0.2,
            servingSize = 100.0,
            servingUnit = "g",
            preparationMethods = listOf(
                "raw",
                "steamed",
                "roasted"
            ),
            lowCalorie = true,
            vegetarian = true,
            vegan = true,
            mealTypes = listOf(
                "Lunch",
                "Dinner",
                "Snack"
            ),
            cuisines = listOf(
                "African",
                "Indian",
                "Asian",
                "Western"
            )
        ),

        Food(
            name = "Cucumber",
            aliases = listOf(
                "cucumber",
                "cucumbers"
            ),
            category = "Vegetable",
            caloriesPer100g = 15.0,
            proteinPer100g = 0.7,
            carbsPer100g = 3.6,
            fatPer100g = 0.1,
            servingSize = 100.0,
            servingUnit = "g",
            preparationMethods = listOf(
                "raw",
                "salad"
            ),
            lowCalorie = true,
            vegetarian = true,
            vegan = true,
            mealTypes = listOf(
                "Lunch",
                "Dinner",
                "Snack"
            ),
            cuisines = listOf(
                "Universal"
            )
        ),

        Food(
            name = "Bell Pepper",
            aliases = listOf(
                "bell pepper",
                "capsicum",
                "pepper"
            ),
            category = "Vegetable",
            caloriesPer100g = 31.0,
            proteinPer100g = 1.0,
            carbsPer100g = 6.0,
            fatPer100g = 0.3,
            servingSize = 100.0,
            servingUnit = "g",
            preparationMethods = listOf(
                "raw",
                "grilled",
                "sautéed"
            ),
            lowCalorie = true,
            vegetarian = true,
            vegan = true,
            mealTypes = listOf(
                "Lunch",
                "Dinner"
            ),
            cuisines = listOf(
                "African",
                "Indian",
                "Asian",
                "Western"
            )
        ),

        Food(
            name = "Green Beans",
            aliases = listOf(
                "green bean",
                "green beans"
            ),
            category = "Vegetable",
            caloriesPer100g = 31.0,
            proteinPer100g = 1.8,
            carbsPer100g = 7.0,
            fatPer100g = 0.2,
            servingSize = 100.0,
            servingUnit = "g",
            preparationMethods = listOf(
                "steamed",
                "boiled",
                "sautéed"
            ),
            lowCalorie = true,
            vegetarian = true,
            vegan = true,
            mealTypes = listOf(
                "Lunch",
                "Dinner"
            ),
            cuisines = listOf(
                "African",
                "Indian",
                "Western"
            )
        ),

        Food(
            name = "Okra",
            aliases = listOf(
                "okra",
                "lady finger",
                "ladyfingers"
            ),
            category = "Vegetable",
            caloriesPer100g = 33.0,
            proteinPer100g = 1.9,
            carbsPer100g = 7.5,
            fatPer100g = 0.2,
            servingSize = 100.0,
            servingUnit = "g",
            preparationMethods = listOf(
                "boiled",
                "stewed",
                "sautéed"
            ),
            lowCalorie = true,
            vegetarian = true,
            vegan = true,
            mealTypes = listOf(
                "Lunch",
                "Dinner"
            ),
            cuisines = listOf(
                "African",
                "Indian"
            )
        ),

        Food(
            name = "Eggplant",
            aliases = listOf(
                "eggplant",
                "aubergine",
                "brinjal"
            ),
            category = "Vegetable",
            caloriesPer100g = 25.0,
            proteinPer100g = 1.0,
            carbsPer100g = 5.9,
            fatPer100g = 0.2,
            servingSize = 100.0,
            servingUnit = "g",
            preparationMethods = listOf(
                "grilled",
                "roasted",
                "stewed"
            ),
            lowCalorie = true,
            vegetarian = true,
            vegan = true,
            mealTypes = listOf(
                "Lunch",
                "Dinner"
            ),
            cuisines = listOf(
                "African",
                "Indian",
                "Mediterranean"
            )
        ),

        Food(
            name = "Cauliflower",
            aliases = listOf(
                "cauliflower"
            ),
            category = "Vegetable",
            caloriesPer100g = 25.0,
            proteinPer100g = 1.9,
            carbsPer100g = 5.0,
            fatPer100g = 0.3,
            servingSize = 100.0,
            servingUnit = "g",
            preparationMethods = listOf(
                "steamed",
                "roasted",
                "boiled"
            ),
            lowCalorie = true,
            vegetarian = true,
            vegan = true,
            mealTypes = listOf(
                "Lunch",
                "Dinner"
            ),
            cuisines = listOf(
                "Indian",
                "Western"
            )
        ),

        // =========================================================
        // FRUITS
        // =========================================================

        Food(
            name = "Banana",
            aliases = listOf(
                "banana",
                "bananas"
            ),
            category = "Fruit",
            caloriesPer100g = 89.0,
            proteinPer100g = 1.1,
            carbsPer100g = 22.8,
            fatPer100g = 0.3,
            servingSize = 118.0,
            servingUnit = "1 medium banana",
            preparationMethods = listOf(
                "raw",
                "smoothie"
            ),
            vegetarian = true,
            vegan = true,
            mealTypes = listOf(
                "Breakfast",
                "Snack"
            ),
            cuisines = listOf(
                "Universal"
            )
        ),

        Food(
            name = "Apple",
            aliases = listOf(
                "apple",
                "apples"
            ),
            category = "Fruit",
            caloriesPer100g = 52.0,
            proteinPer100g = 0.3,
            carbsPer100g = 13.8,
            fatPer100g = 0.2,
            servingSize = 182.0,
            servingUnit = "1 medium apple",
            preparationMethods = listOf(
                "raw",
                "sliced"
            ),
            lowCalorie = true,
            vegetarian = true,
            vegan = true,
            mealTypes = listOf(
                "Breakfast",
                "Snack"
            ),
            cuisines = listOf(
                "Universal"
            )
        ),

        Food(
            name = "Orange",
            aliases = listOf(
                "orange",
                "oranges"
            ),
            category = "Fruit",
            caloriesPer100g = 47.0,
            proteinPer100g = 0.9,
            carbsPer100g = 11.8,
            fatPer100g = 0.1,
            servingSize = 130.0,
            servingUnit = "1 medium orange",
            preparationMethods = listOf(
                "raw",
                "juice"
            ),
            lowCalorie = true,
            vegetarian = true,
            vegan = true,
            mealTypes = listOf(
                "Breakfast",
                "Snack"
            ),
            cuisines = listOf(
                "Universal"
            )
        ),

        Food(
            name = "Mango",
            aliases = listOf(
                "mango",
                "mangoes"
            ),
            category = "Fruit",
            caloriesPer100g = 60.0,
            proteinPer100g = 0.8,
            carbsPer100g = 15.0,
            fatPer100g = 0.4,
            servingSize = 165.0,
            servingUnit = "1 cup",
            preparationMethods = listOf(
                "raw",
                "smoothie"
            ),
            vegetarian = true,
            vegan = true,
            mealTypes = listOf(
                "Breakfast",
                "Snack"
            ),
            cuisines = listOf(
                "African",
                "Indian",
                "Asian"
            )
        ),

        Food(
            name = "Pineapple",
            aliases = listOf(
                "pineapple"
            ),
            category = "Fruit",
            caloriesPer100g = 50.0,
            proteinPer100g = 0.5,
            carbsPer100g = 13.1,
            fatPer100g = 0.1,
            servingSize = 165.0,
            servingUnit = "1 cup",
            preparationMethods = listOf(
                "raw",
                "smoothie"
            ),
            lowCalorie = true,
            vegetarian = true,
            vegan = true,
            mealTypes = listOf(
                "Breakfast",
                "Snack"
            ),
            cuisines = listOf(
                "Universal"
            )
        ),

        Food(
            name = "Watermelon",
            aliases = listOf(
                "watermelon"
            ),
            category = "Fruit",
            caloriesPer100g = 30.0,
            proteinPer100g = 0.6,
            carbsPer100g = 7.6,
            fatPer100g = 0.2,
            servingSize = 150.0,
            servingUnit = "g",
            preparationMethods = listOf(
                "raw"
            ),
            lowCalorie = true,
            vegetarian = true,
            vegan = true,
            mealTypes = listOf(
                "Breakfast",
                "Snack"
            ),
            cuisines = listOf(
                "Universal"
            )
        ),

        Food(
            name = "Papaya",
            aliases = listOf(
                "papaya",
                "pawpaw"
            ),
            category = "Fruit",
            caloriesPer100g = 43.0,
            proteinPer100g = 0.5,
            carbsPer100g = 11.0,
            fatPer100g = 0.3,
            servingSize = 150.0,
            servingUnit = "g",
            preparationMethods = listOf(
                "raw",
                "smoothie"
            ),
            lowCalorie = true,
            vegetarian = true,
            vegan = true,
            mealTypes = listOf(
                "Breakfast",
                "Snack"
            ),
            cuisines = listOf(
                "African",
                "Asian"
            )
        ),

        Food(
            name = "Avocado",
            aliases = listOf(
                "avocado",
                "avocados"
            ),
            category = "Healthy Fat",
            caloriesPer100g = 160.0,
            proteinPer100g = 2.0,
            carbsPer100g = 8.5,
            fatPer100g = 14.7,
            servingSize = 100.0,
            servingUnit = "g",
            preparationMethods = listOf(
                "raw",
                "salad",
                "mashed"
            ),
            vegetarian = true,
            vegan = true,
            mealTypes = listOf(
                "Breakfast",
                "Lunch",
                "Dinner",
                "Snack"
            ),
            cuisines = listOf(
                "African",
                "Western",
                "Universal"
            )
        ),

        Food(
            name = "Guava",
            aliases = listOf(
                "guava",
                "guavas"
            ),
            category = "Fruit",
            caloriesPer100g = 68.0,
            proteinPer100g = 2.6,
            carbsPer100g = 14.3,
            fatPer100g = 1.0,
            servingSize = 100.0,
            servingUnit = "g",
            preparationMethods = listOf(
                "raw"
            ),
            vegetarian = true,
            vegan = true,
            mealTypes = listOf(
                "Breakfast",
                "Snack"
            ),
            cuisines = listOf(
                "African",
                "Indian",
                "Asian"
            )
        ),

        // =========================================================
        // DAIRY
        // =========================================================

        Food(
            name = "Milk",
            aliases = listOf(
                "milk",
                "whole milk"
            ),
            category = "Dairy",
            caloriesPer100g = 61.0,
            proteinPer100g = 3.2,
            carbsPer100g = 4.8,
            fatPer100g = 3.3,
            servingSize = 250.0,
            servingUnit = "ml",
            preparationMethods = listOf(
                "fresh",
                "heated"
            ),
            vegetarian = true,
            mealTypes = listOf(
                "Breakfast",
                "Snack"
            ),
            cuisines = listOf(
                "Universal"
            )
        ),

        Food(
            name = "Greek Yogurt",
            aliases = listOf(
                "greek yogurt",
                "greek yoghurt"
            ),
            category = "Dairy",
            caloriesPer100g = 59.0,
            proteinPer100g = 10.0,
            carbsPer100g = 3.6,
            fatPer100g = 0.4,
            servingSize = 170.0,
            servingUnit = "g",
            preparationMethods = listOf(
                "fresh",
                "bowl"
            ),
            highProtein = true,
            vegetarian = true,
            mealTypes = listOf(
                "Breakfast",
                "Snack"
            ),
            cuisines = listOf(
                "Universal"
            )
        ),

        Food(
            name = "Plain Yogurt",
            aliases = listOf(
                "yogurt",
                "yoghurt",
                "plain yogurt"
            ),
            category = "Dairy",
            caloriesPer100g = 61.0,
            proteinPer100g = 3.5,
            carbsPer100g = 4.7,
            fatPer100g = 3.3,
            servingSize = 170.0,
            servingUnit = "g",
            preparationMethods = listOf(
                "fresh",
                "bowl"
            ),
            vegetarian = true,
            mealTypes = listOf(
                "Breakfast",
                "Snack"
            ),
            cuisines = listOf(
                "Universal"
            )
        ),

        Food(
            name = "Cottage Cheese",
            aliases = listOf(
                "cottage cheese"
            ),
            category = "Dairy",
            caloriesPer100g = 98.0,
            proteinPer100g = 11.1,
            carbsPer100g = 3.4,
            fatPer100g = 4.3,
            servingSize = 150.0,
            servingUnit = "g",
            preparationMethods = listOf(
                "fresh",
                "bowl"
            ),
            highProtein = true,
            vegetarian = true,
            mealTypes = listOf(
                "Breakfast",
                "Snack",
                "Lunch"
            ),
            cuisines = listOf(
                "Universal"
            )
        ),

        // =========================================================
        // NUTS & HEALTHY FATS
        // =========================================================

        Food(
            name = "Peanut Butter",
            aliases = listOf(
                "peanut butter",
                "groundnut butter"
            ),
            category = "Healthy Fat",
            caloriesPer100g = 588.0,
            proteinPer100g = 25.1,
            carbsPer100g = 20.0,
            fatPer100g = 50.0,
            servingSize = 32.0,
            servingUnit = "2 tablespoons",
            preparationMethods = listOf(
                "spread",
                "mixed",
                "smoothie"
            ),
            highProtein = true,
            vegetarian = true,
            vegan = true,
            mealTypes = listOf(
                "Breakfast",
                "Snack"
            ),
            cuisines = listOf(
                "African",
                "Universal"
            )
        ),

        Food(
            name = "Peanuts",
            aliases = listOf(
                "peanut",
                "peanuts",
                "groundnuts",
                "groundnut"
            ),
            category = "Healthy Fat",
            caloriesPer100g = 567.0,
            proteinPer100g = 25.8,
            carbsPer100g = 16.1,
            fatPer100g = 49.2,
            servingSize = 30.0,
            servingUnit = "g",
            preparationMethods = listOf(
                "raw",
                "roasted"
            ),
            highProtein = true,
            vegetarian = true,
            vegan = true,
            mealTypes = listOf(
                "Snack"
            ),
            cuisines = listOf(
                "African",
                "Indian",
                "Asian"
            )
        ),

        Food(
            name = "Almonds",
            aliases = listOf(
                "almond",
                "almonds"
            ),
            category = "Healthy Fat",
            caloriesPer100g = 579.0,
            proteinPer100g = 21.2,
            carbsPer100g = 21.6,
            fatPer100g = 49.9,
            servingSize = 28.0,
            servingUnit = "g",
            preparationMethods = listOf(
                "raw",
                "roasted"
            ),
            highProtein = true,
            vegetarian = true,
            vegan = true,
            mealTypes = listOf(
                "Snack",
                "Breakfast"
            ),
            cuisines = listOf(
                "Universal"
            )
        ),

        Food(
            name = "Cashews",
            aliases = listOf(
                "cashew",
                "cashews"
            ),
            category = "Healthy Fat",
            caloriesPer100g = 553.0,
            proteinPer100g = 18.2,
            carbsPer100g = 30.2,
            fatPer100g = 43.8,
            servingSize = 28.0,
            servingUnit = "g",
            preparationMethods = listOf(
                "raw",
                "roasted"
            ),
            vegetarian = true,
            vegan = true,
            mealTypes = listOf(
                "Snack",
                "Breakfast"
            ),
            cuisines = listOf(
                "African",
                "Indian",
                "Asian"
            )
        ),

        Food(
            name = "Chia Seeds",
            aliases = listOf(
                "chia",
                "chia seeds"
            ),
            category = "Healthy Fat",
            caloriesPer100g = 486.0,
            proteinPer100g = 16.5,
            carbsPer100g = 42.1,
            fatPer100g = 30.7,
            servingSize = 15.0,
            servingUnit = "1 tablespoon",
            preparationMethods = listOf(
                "mixed",
                "overnight oats"
            ),
            vegetarian = true,
            vegan = true,
            mealTypes = listOf(
                "Breakfast",
                "Snack"
            ),
            cuisines = listOf(
                "Universal"
            )
        ),

        Food(
            name = "Olive Oil",
            aliases = listOf(
                "olive oil"
            ),
            category = "Healthy Fat",
            caloriesPer100g = 884.0,
            proteinPer100g = 0.0,
            carbsPer100g = 0.0,
            fatPer100g = 100.0,
            servingSize = 14.0,
            servingUnit = "1 tablespoon",
            preparationMethods = listOf(
                "cooking",
                "dressing"
            ),
            vegetarian = true,
            vegan = true,
            mealTypes = listOf(
                "Lunch",
                "Dinner"
            ),
            cuisines = listOf(
                "Mediterranean",
                "Universal"
            )
        )
    )

    fun getFood(name: String): Food? {
        return foods.firstOrNull { food ->

            food.name.equals(
                name.trim(),
                ignoreCase = true
            ) ||

                    food.aliases.any { alias ->

                        alias.equals(
                            name.trim(),
                            ignoreCase = true
                        )
                    }
        }
    }

    fun getAllFoods(): List<Food> {
        return foods
    }
}