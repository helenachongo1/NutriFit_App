package com.nutrifit.app

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.mlkit.vision.barcode.common.Barcode
import com.google.mlkit.vision.codescanner.GmsBarcodeScannerOptions
import com.google.mlkit.vision.codescanner.GmsBarcodeScanning

class ScannerActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        startBarcodeScanner()
    }

    private fun startBarcodeScanner() {

        val options = GmsBarcodeScannerOptions.Builder()
            .setBarcodeFormats(
                Barcode.FORMAT_EAN_13,
                Barcode.FORMAT_EAN_8,
                Barcode.FORMAT_UPC_A,
                Barcode.FORMAT_UPC_E,
                Barcode.FORMAT_QR_CODE
            )
            .enableAutoZoom()
            .build()

        val scanner = GmsBarcodeScanning.getClient(
            this,
            options
        )

        scanner.startScan()
            .addOnSuccessListener { barcode ->

                val rawValue = barcode.rawValue

                if (!rawValue.isNullOrEmpty()) {
                    handleBarcode(rawValue)
                } else {
                    Toast.makeText(
                        this,
                        "No barcode value found",
                        Toast.LENGTH_SHORT
                    ).show()

                    finish()
                }
            }
            .addOnCanceledListener {
                finish()
            }
            .addOnFailureListener { exception ->

                Toast.makeText(
                    this,
                    "Scanner error: ${exception.message}",
                    Toast.LENGTH_LONG
                ).show()

                finish()
            }
    }

    private fun handleBarcode(barcodeValue: String) {

        val food = BarcodeDatabase.getFood(barcodeValue)

        if (food != null) {

            val intent = Intent(
                this,
                ManualFoodActivity::class.java
            )

            intent.putExtra(
                "barcode",
                barcodeValue
            )

            intent.putExtra(
                "foodName",
                food.name
            )

            startActivity(intent)

        } else {

            Toast.makeText(
                this,
                "Product not found. Please enter the food manually.",
                Toast.LENGTH_LONG
            ).show()

            val intent = Intent(
                this,
                ManualFoodActivity::class.java
            )

            intent.putExtra(
                "barcode",
                barcodeValue
            )

            startActivity(intent)
        }

        finish()
    }
}