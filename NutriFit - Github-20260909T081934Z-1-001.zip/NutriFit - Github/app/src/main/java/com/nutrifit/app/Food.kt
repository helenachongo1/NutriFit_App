package com.nutrifit.app

data class Food(
    val name: String,
    val aliases: List<String>,
    val category: String,

    val caloriesPer100g: Double,
    val proteinPer100g: Double,
    val carbsPer100g: Double,
    val fatPer100g: Double,

    val servingSize: Double,
    val servingUnit: String,

    val preparationMethods: List<String>,

    val highProtein: Boolean = false,
    val lowCalorie: Boolean = false,
    val vegetarian: Boolean = false,
    val vegan: Boolean = false,

    val mealTypes: List<String> = emptyList(),
    val cuisines: List<String> = emptyList()
)