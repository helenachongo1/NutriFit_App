package com.nutrifit.app

data class MealRecommendation(
    val name: String,
    val ingredients: List<Food>,
    val calories: Double,
    val protein: Double,
    val carbs: Double,
    val fat: Double,
    val preparationTime: Int,
    val reason: String,
    val preparation: String
)

object MealRecommendationEngine {

    fun generateRecommendations(
        availableFoods: List<Food>,
        goal: String,
        maxTime: Int,
        cuisine: String = "Any"
    ): List<MealRecommendation> {

        if (availableFoods.isEmpty()) {
            return emptyList()
        }

        val proteins = availableFoods.filter {
            it.category.equals("Protein", ignoreCase = true)
        }

        val carbohydrates = availableFoods.filter {
            it.category.equals("Carbohydrate", ignoreCase = true)
        }

        val vegetables = availableFoods.filter {
            it.category.equals("Vegetable", ignoreCase = true)
        }

        val fruits = availableFoods.filter {
            it.category.equals("Fruit", ignoreCase = true)
        }

        val dairy = availableFoods.filter {
            it.category.equals("Dairy", ignoreCase = true)
        }

        val healthyFats = availableFoods.filter {
            it.category.equals("Healthy Fat", ignoreCase = true)
        }

        val recommendations =
            mutableListOf<MealRecommendation>()

        /*
         * Protein + carbohydrate combinations
         */
        if (
            proteins.isNotEmpty() &&
            carbohydrates.isNotEmpty()
        ) {

            proteins.forEach { protein ->

                carbohydrates.forEach { carbohydrate ->

                    val ingredients =
                        mutableListOf<Food>()

                    ingredients.add(protein)
                    ingredients.add(carbohydrate)

                    val vegetable =
                        vegetables.firstOrNull()

                    if (vegetable != null) {
                        ingredients.add(vegetable)
                    }

                    recommendations.add(
                        createMeal(
                            ingredients = ingredients,
                            goal = goal
                        )
                    )
                }
            }
        }

        /*
         * Protein + vegetables
         */
        if (
            proteins.isNotEmpty() &&
            vegetables.isNotEmpty()
        ) {

            proteins.forEach { protein ->

                vegetables.forEach { vegetable ->

                    recommendations.add(
                        createMeal(
                            ingredients =
                                listOf(
                                    protein,
                                    vegetable
                                ),
                            goal = goal
                        )
                    )
                }
            }
        }

        /*
         * Dairy + fruit
         */
        if (
            dairy.isNotEmpty() &&
            fruits.isNotEmpty()
        ) {

            dairy.forEach { dairyFood ->

                fruits.forEach { fruit ->

                    val ingredients =
                        mutableListOf<Food>()

                    ingredients.add(dairyFood)
                    ingredients.add(fruit)

                    val healthyFat =
                        healthyFats.firstOrNull()

                    if (healthyFat != null) {
                        ingredients.add(healthyFat)
                    }

                    recommendations.add(
                        createMeal(
                            ingredients = ingredients,
                            goal = goal
                        )
                    )
                }
            }
        }

        /*
         * Fruit + healthy fat
         */
        if (
            fruits.isNotEmpty() &&
            healthyFats.isNotEmpty()
        ) {

            fruits.forEach { fruit ->

                healthyFats.forEach { healthyFat ->

                    recommendations.add(
                        createMeal(
                            ingredients =
                                listOf(
                                    fruit,
                                    healthyFat
                                ),
                            goal = goal
                        )
                    )
                }
            }
        }

        /*
         * If there are no category-specific
         * combinations, create a simple meal
         * from the available foods.
         */
        if (recommendations.isEmpty()) {

            val simpleIngredients =
                availableFoods.take(3)

            recommendations.add(
                createMeal(
                    ingredients =
                        simpleIngredients,
                    goal = goal
                )
            )
        }

        /*
         * Remove duplicate combinations.
         */
        val uniqueRecommendations =
            recommendations.distinctBy { meal ->

                meal.ingredients
                    .map {
                        it.name.lowercase()
                    }
                    .sorted()
                    .joinToString("|")
            }

        /*
         * Try to respect the selected preparation
         * time first.
         */
        val timeMatched =
            if (maxTime == 999) {

                uniqueRecommendations

            } else {

                uniqueRecommendations.filter {
                    it.preparationTime <= maxTime
                }
            }

        /*
         * If nothing fits the selected time,
         * return the closest available meals.
         */
        val mealsToRank =
            if (timeMatched.isNotEmpty()) {

                timeMatched

            } else {

                uniqueRecommendations
                    .sortedBy {
                        kotlin.math.abs(
                            it.preparationTime - maxTime
                        )
                    }
            }

        /*
         * Rank recommendations using BOTH:
         *
         * 1. Fitness goal
         * 2. Cuisine preference
         */
        return mealsToRank
            .sortedByDescending {

                calculateScore(
                    meal = it,
                    goal = goal,
                    cuisine = cuisine
                )
            }
            .take(3)
    }

    private fun createMeal(
        ingredients: List<Food>,
        goal: String
    ): MealRecommendation {

        /*
         * TEMPORARY nutrition calculation.
         *
         * Currently uses 100 g of each ingredient.
         * We will replace this with realistic serving
         * sizes later.
         */
        val calories =
            ingredients.sumOf {
                it.caloriesPer100g
            }

        val protein =
            ingredients.sumOf {
                it.proteinPer100g
            }

        val carbs =
            ingredients.sumOf {
                it.carbsPer100g
            }

        val fat =
            ingredients.sumOf {
                it.fatPer100g
            }

        val preparationTime =
            calculatePreparationTime(
                ingredients
            )

        val mealName =
            createMealName(
                ingredients
            )

        val reason =
            createReason(
                protein = protein,
                calories = calories,
                fat = fat,
                goal = goal
            )

        val preparation =
            createPreparation(
                ingredients
            )

        return MealRecommendation(
            name = mealName,
            ingredients = ingredients,
            calories = calories,
            protein = protein,
            carbs = carbs,
            fat = fat,
            preparationTime = preparationTime,
            reason = reason,
            preparation = preparation
        )
    }

    /*
     * Calculate the recommendation score.
     *
     * Cuisine is used as a preference rather than
     * a strict filter. This means NutriFit can still
     * recommend a meal when there is no perfect
     * cuisine match.
     */
    private fun calculateScore(
        meal: MealRecommendation,
        goal: String,
        cuisine: String
    ): Double {

        var score =
            when (goal) {

                "High Protein" -> {

                    meal.protein * 4.0 -
                            meal.fat * 0.5
                }

                "Lower Calorie" -> {

                    1000.0 -
                            meal.calories
                }

                "High Energy" -> {

                    meal.calories * 1.5 +
                            meal.protein
                }

                else -> {

                    /*
                     * Balanced meal:
                     * reward protein and carbohydrates
                     * while avoiding excessive fat.
                     */
                    meal.protein * 2.0 +
                            meal.carbs * 0.5 -
                            meal.fat * 0.5
                }
            }

        /*
         * Cuisine preference scoring.
         *
         * Each ingredient matching the selected
         * cuisine adds points.
         */
        if (
            cuisine.isNotBlank() &&
            !cuisine.equals(
                "Any",
                ignoreCase = true
            )
        ) {

            val cuisineMatches =
                meal.ingredients.count { food ->

                    food.cuisines.any {
                        it.equals(
                            cuisine,
                            ignoreCase = true
                        )
                    }
                }

            score +=
                cuisineMatches * 20.0

            /*
             * Give an additional bonus when every
             * ingredient belongs to the preferred
             * cuisine.
             */
            if (
                cuisineMatches ==
                meal.ingredients.size
            ) {

                score += 15.0
            }
        }

        return score
    }

    private fun createMealName(
        ingredients: List<Food>
    ): String {

        val protein =
            ingredients.firstOrNull {
                it.category.equals(
                    "Protein",
                    ignoreCase = true
                )
            }

        val carbohydrate =
            ingredients.firstOrNull {
                it.category.equals(
                    "Carbohydrate",
                    ignoreCase = true
                )
            }

        val vegetable =
            ingredients.firstOrNull {
                it.category.equals(
                    "Vegetable",
                    ignoreCase = true
                )
            }

        val dairy =
            ingredients.firstOrNull {
                it.category.equals(
                    "Dairy",
                    ignoreCase = true
                )
            }

        val fruit =
            ingredients.firstOrNull {
                it.category.equals(
                    "Fruit",
                    ignoreCase = true
                )
            }

        if (
            protein != null &&
            carbohydrate != null &&
            vegetable != null
        ) {

            return "${protein.name} & " +
                    "${vegetable.name} " +
                    "${carbohydrate.name} Bowl"
        }

        if (
            protein != null &&
            carbohydrate != null
        ) {

            return "${protein.name} & " +
                    "${carbohydrate.name} Plate"
        }

        if (
            protein != null &&
            vegetable != null
        ) {

            return "${protein.name} & " +
                    "${vegetable.name} Power Meal"
        }

        if (
            dairy != null &&
            fruit != null
        ) {

            return "${dairy.name} & " +
                    "${fruit.name} Bowl"
        }

        if (
            fruit != null &&
            ingredients.any {
                it.category.equals(
                    "Healthy Fat",
                    ignoreCase = true
                )
            }
        ) {

            return "${fruit.name} Energy Snack"
        }

        return ingredients.joinToString(
            " & "
        ) {
            it.name
        }
    }

    private fun calculatePreparationTime(
        ingredients: List<Food>
    ): Int {

        var time = 5

        ingredients.forEach { food ->

            time += when {

                food.category.equals(
                    "Protein",
                    ignoreCase = true
                ) -> 10

                food.category.equals(
                    "Carbohydrate",
                    ignoreCase = true
                ) -> 8

                food.category.equals(
                    "Vegetable",
                    ignoreCase = true
                ) -> 5

                food.category.equals(
                    "Dairy",
                    ignoreCase = true
                ) -> 2

                food.category.equals(
                    "Fruit",
                    ignoreCase = true
                ) -> 2

                food.category.equals(
                    "Healthy Fat",
                    ignoreCase = true
                ) -> 2

                else -> 5
            }
        }

        return time.coerceAtMost(45)
    }

    private fun createReason(
        protein: Double,
        calories: Double,
        fat: Double,
        goal: String
    ): String {

        return when (goal) {

            "High Protein" -> {

                "Recommended because it provides " +
                        "${protein.toInt()} g of protein " +
                        "to support your high-protein goal."
            }

            "Lower Calorie" -> {

                "Recommended because it provides " +
                        "${calories.toInt()} kcal while " +
                        "keeping the meal relatively light."
            }

            "High Energy" -> {

                "Recommended because it provides " +
                        "${calories.toInt()} kcal for " +
                        "additional energy."
            }

            else -> {

                "Recommended as a balanced combination " +
                        "of protein, carbohydrates and other " +
                        "available nutrients."
            }
        }
    }

    private fun createPreparation(
        ingredients: List<Food>
    ): String {

        val steps =
            mutableListOf<String>()

        ingredients.forEach { food ->

            when {

                food.category.equals(
                    "Protein",
                    ignoreCase = true
                ) -> {

                    steps.add(
                        "Cook the " +
                                "${food.name.lowercase()} " +
                                "until fully cooked."
                    )
                }

                food.category.equals(
                    "Carbohydrate",
                    ignoreCase = true
                ) -> {

                    steps.add(
                        "Prepare the " +
                                "${food.name.lowercase()} " +
                                "according to your preferred method."
                    )
                }

                food.category.equals(
                    "Vegetable",
                    ignoreCase = true
                ) -> {

                    steps.add(
                        "Steam or lightly sauté the " +
                                "${food.name.lowercase()}."
                    )
                }

                food.category.equals(
                    "Fruit",
                    ignoreCase = true
                ) -> {

                    steps.add(
                        "Wash and prepare the " +
                                "${food.name.lowercase()}."
                    )
                }

                food.category.equals(
                    "Dairy",
                    ignoreCase = true
                ) -> {

                    steps.add(
                        "Add the " +
                                "${food.name.lowercase()} " +
                                "as a side or topping."
                    )
                }

                food.category.equals(
                    "Healthy Fat",
                    ignoreCase = true
                ) -> {

                    steps.add(
                        "Add a small portion of " +
                                "${food.name.lowercase()}."
                    )
                }

                else -> {

                    steps.add(
                        "Prepare the " +
                                "${food.name.lowercase()} " +
                                "as desired."
                    )
                }
            }
        }

        steps.add(
            "Combine the prepared ingredients " +
                    "and serve."
        )

        return steps.mapIndexed {
                index,
                step
            ->

            "${index + 1}. $step"

        }.joinToString("\n")
    }
}