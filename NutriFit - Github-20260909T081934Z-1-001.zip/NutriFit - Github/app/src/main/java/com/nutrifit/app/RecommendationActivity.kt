package com.nutrifit.app

import android.graphics.Typeface
import android.os.Bundle
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import java.util.Locale

class RecommendationActivity : AppCompatActivity() {

    private lateinit var etIngredients: EditText
    private lateinit var ingredientsContainer: LinearLayout
    private lateinit var btnClearIngredients: Button

    private lateinit var rgCuisine: RadioGroup
    private lateinit var rgGoal: RadioGroup
    private lateinit var spinnerTime: Spinner
    private lateinit var btnGenerateMeals: Button

    private lateinit var recommendationsContainer: LinearLayout
    private lateinit var tvRecommendationTitle: TextView
    private lateinit var recommendationScrollView: ScrollView

    private val selectedIngredients =
        mutableListOf<String>()

    override fun onCreate(
        savedInstanceState: Bundle?
    ) {

        super.onCreate(savedInstanceState)

        setContentView(
            R.layout.activity_recommendations
        )

        recommendationScrollView =
            findViewById(
                R.id.recommendationScrollView
            )

        etIngredients =
            findViewById(
                R.id.etIngredients
            )

        ingredientsContainer =
            findViewById(
                R.id.ingredientsContainer
            )

        btnClearIngredients =
            findViewById(
                R.id.btnClearIngredients
            )

        // Cuisine selection
        rgCuisine =
            findViewById(
                R.id.rgCuisine
            )

        // Fitness goal selection
        rgGoal =
            findViewById(
                R.id.rgGoal
            )

        spinnerTime =
            findViewById(
                R.id.spinnerTime
            )

        btnGenerateMeals =
            findViewById(
                R.id.btnGenerateMeals
            )

        recommendationsContainer =
            findViewById(
                R.id.recommendationsContainer
            )

        tvRecommendationTitle =
            findViewById(
                R.id.tvRecommendationTitle
            )

        setupTimeSpinner()

        findViewById<Button>(
            R.id.btnAddIngredient
        ).setOnClickListener {

            addIngredients()
        }

        btnClearIngredients.setOnClickListener {

            selectedIngredients.clear()

            updateIngredientList()

            recommendationsContainer.removeAllViews()

            tvRecommendationTitle.visibility =
                View.GONE

            Toast.makeText(
                this,
                "All ingredients cleared.",
                Toast.LENGTH_SHORT
            ).show()
        }

        btnGenerateMeals.setOnClickListener {

            generateMeals()
        }

        updateIngredientList()
    }

    private fun setupTimeSpinner() {

        val timeOptions =
            listOf(
                "10 minutes",
                "20 minutes",
                "30 minutes",
                "45 minutes",
                "No limit"
            )

        val adapter =
            ArrayAdapter(
                this,
                android.R.layout.simple_spinner_item,
                timeOptions
            )

        adapter.setDropDownViewResource(
            android.R.layout.simple_spinner_dropdown_item
        )

        spinnerTime.adapter =
            adapter
    }

    private fun addIngredients() {

        val input =
            etIngredients.text
                .toString()
                .trim()

        if (input.isEmpty()) {

            Toast.makeText(
                this,
                "Please enter at least one ingredient.",
                Toast.LENGTH_SHORT
            ).show()

            return
        }

        val ingredients =
            input.split(
                ",",
                "\n"
            )

        var addedCount = 0

        ingredients.forEach { ingredient ->

            val cleaned =
                ingredient.trim()

            if (cleaned.isEmpty()) {
                return@forEach
            }

            val food =
                findFood(cleaned)

            if (food != null) {

                val alreadyAdded =
                    selectedIngredients.any {
                        it.equals(
                            food.name,
                            ignoreCase = true
                        )
                    }

                if (!alreadyAdded) {

                    selectedIngredients.add(
                        food.name
                    )

                    addedCount++
                }

            } else {

                Toast.makeText(
                    this,
                    "\"$cleaned\" is not in the NutriFit food database.",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }

        etIngredients.text.clear()

        updateIngredientList()

        if (addedCount > 0) {

            Toast.makeText(
                this,
                "$addedCount ingredient(s) added.",
                Toast.LENGTH_SHORT
            ).show()
        }
    }

    private fun findFood(
        name: String
    ): Food? {

        return FoodDatabase.getFood(
            name
        )
    }

    private fun updateIngredientList() {

        ingredientsContainer.removeAllViews()

        if (selectedIngredients.isEmpty()) {

            val emptyText =
                TextView(this)

            emptyText.text =
                "No ingredients added yet."

            emptyText.textSize =
                14f

            emptyText.setTextColor(
                getColor(
                    R.color.nutrifit_text_secondary
                )
            )

            ingredientsContainer.addView(
                emptyText
            )

            btnClearIngredients.visibility =
                View.GONE

            return
        }

        selectedIngredients.forEach { ingredient ->

            addIngredientRow(
                ingredient
            )
        }

        btnClearIngredients.visibility =
            View.VISIBLE
    }

    private fun addIngredientRow(
        ingredientName: String
    ) {

        val row =
            LinearLayout(this)

        row.orientation =
            LinearLayout.HORIZONTAL

        row.gravity =
            android.view.Gravity.CENTER_VERTICAL

        val rowParams =
            LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )

        rowParams.setMargins(
            0,
            0,
            0,
            6
        )

        row.layoutParams =
            rowParams

        val name =
            TextView(this)

        name.text =
            "• $ingredientName"

        name.textSize =
            15f

        name.setTextColor(
            getColor(
                R.color.nutrifit_text
            )
        )

        name.layoutParams =
            LinearLayout.LayoutParams(
                0,
                LinearLayout.LayoutParams.WRAP_CONTENT,
                1f
            )

        val removeButton =
            Button(this)

        removeButton.text =
            "Remove"

        removeButton.textSize =
            12f

        removeButton.setAllCaps(
            false
        )

        removeButton.setOnClickListener {

            selectedIngredients.removeAll {
                it.equals(
                    ingredientName,
                    ignoreCase = true
                )
            }

            updateIngredientList()

            Toast.makeText(
                this,
                "$ingredientName removed.",
                Toast.LENGTH_SHORT
            ).show()
        }

        row.addView(
            name
        )

        row.addView(
            removeButton
        )

        ingredientsContainer.addView(
            row
        )
    }

    private fun generateMeals() {

        /*
         * If the user typed ingredients but did
         * not press Add Ingredient, process them now.
         */
        val currentInput =
            etIngredients.text
                .toString()
                .trim()

        if (currentInput.isNotEmpty()) {
            addIngredients()
        }

        if (selectedIngredients.isEmpty()) {

            Toast.makeText(
                this,
                "Please add some ingredients first.",
                Toast.LENGTH_SHORT
            ).show()

            return
        }

        val availableFoods =
            selectedIngredients.mapNotNull {
                findFood(it)
            }

        if (availableFoods.isEmpty()) {

            Toast.makeText(
                this,
                "No recognized ingredients were found.",
                Toast.LENGTH_SHORT
            ).show()

            return
        }

        // Get selected cuisine
        val cuisine =
            when (
                rgCuisine.checkedRadioButtonId
            ) {

                R.id.rbAfrican ->
                    "African"

                R.id.rbIndian ->
                    "Indian"

                R.id.rbWestern ->
                    "Western"

                R.id.rbAsian ->
                    "Asian"

                else ->
                    "Any"
            }

        // Get selected fitness goal
        val goal =
            when (
                rgGoal.checkedRadioButtonId
            ) {

                R.id.rbHighProtein ->
                    "High Protein"

                R.id.rbLowCalorie ->
                    "Lower Calorie"

                R.id.rbHighEnergy ->
                    "High Energy"

                else ->
                    "Balanced Meal"
            }

        // Get maximum preparation time
        val maxTime =
            when (
                spinnerTime.selectedItemPosition
            ) {

                0 -> 10
                1 -> 20
                2 -> 30
                3 -> 45
                else -> 999
            }

        // Generate recommendations using
        // ingredients + cuisine + goal + time
        val recommendations =
            MealRecommendationEngine
                .generateRecommendations(
                    availableFoods =
                        availableFoods,
                    goal =
                        goal,
                    maxTime =
                        maxTime,
                    cuisine =
                        cuisine
                )

        displayRecommendations(
            recommendations
        )
    }

    private fun displayRecommendations(
        recommendations:
        List<MealRecommendation>
    ) {

        recommendationsContainer
            .removeAllViews()

        tvRecommendationTitle.visibility =
            View.VISIBLE

        if (recommendations.isEmpty()) {

            tvRecommendationTitle.text =
                "No matching meals found"

            val message =
                TextView(this)

            message.text =
                "Try adding more ingredients or " +
                        "selecting a longer preparation time."

            message.textSize =
                16f

            message.setTextColor(
                getColor(
                    R.color.nutrifit_text_secondary
                )
            )

            message.setPadding(
                0,
                10,
                0,
                20
            )

            recommendationsContainer
                .addView(
                    message
                )

            recommendationScrollView.post {

                recommendationScrollView.smoothScrollTo(
                    0,
                    recommendationsContainer.bottom
                )
            }

            return
        }

        tvRecommendationTitle.text =
            "Your Recommendations"

        recommendations.forEachIndexed {
                index,
                meal
            ->

            addRecommendationCard(
                meal =
                    meal,
                position =
                    index + 1
            )
        }

        recommendationScrollView.post {

            recommendationScrollView.smoothScrollTo(
                0,
                recommendationsContainer.bottom
            )
        }
    }

    private fun addRecommendationCard(
        meal: MealRecommendation,
        position: Int
    ) {

        val card =
            LinearLayout(this)

        card.orientation =
            LinearLayout.VERTICAL

        card.setPadding(
            18,
            18,
            18,
            18
        )

        card.setBackgroundColor(
            getColor(
                R.color.nutrifit_surface
            )
        )

        val cardParams =
            LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )

        cardParams.setMargins(
            0,
            0,
            0,
            16
        )

        card.layoutParams =
            cardParams

        val title =
            TextView(this)

        title.text =
            "$position. ${meal.name}"

        title.textSize =
            19f

        title.setTypeface(
            null,
            Typeface.BOLD
        )

        title.setTextColor(
            getColor(
                R.color.nutrifit_primary
            )
        )

        val ingredients =
            TextView(this)

        ingredients.text =
            "Ingredients:\n" +
                    meal.ingredients.joinToString(
                        separator = "\n"
                    ) {
                        "• ${it.name}"
                    }

        ingredients.textSize =
            15f

        ingredients.setTextColor(
            getColor(
                R.color.nutrifit_text
            )
        )

        ingredients.setPadding(
            0,
            12,
            0,
            10
        )

        val nutrition =
            TextView(this)

        nutrition.text =
            String.format(
                Locale.getDefault(),
                "Estimated nutrition:\n" +
                        "%.0f kcal  •  %.0f g protein\n" +
                        "%.0f g carbs  •  %.0f g fat",
                meal.calories,
                meal.protein,
                meal.carbs,
                meal.fat
            )

        nutrition.textSize =
            15f

        nutrition.setTextColor(
            getColor(
                R.color.nutrifit_text
            )
        )

        val time =
            TextView(this)

        time.text =
            "Preparation time: " +
                    "${meal.preparationTime} minutes"

        time.textSize =
            14f

        time.setTextColor(
            getColor(
                R.color.nutrifit_text_secondary
            )
        )

        time.setPadding(
            0,
            8,
            0,
            8
        )

        val reason =
            TextView(this)

        reason.text =
            "Why this is recommended:\n" +
                    meal.reason

        reason.textSize =
            14f

        reason.setTextColor(
            getColor(
                R.color.nutrifit_text_secondary
            )
        )

        reason.setPadding(
            0,
            8,
            0,
            10
        )

        val preparation =
            TextView(this)

        preparation.text =
            "Preparation:\n" +
                    meal.preparation

        preparation.textSize =
            14f

        preparation.setTextColor(
            getColor(
                R.color.nutrifit_text
            )
        )

        preparation.setPadding(
            0,
            6,
            0,
            0
        )

        card.addView(
            title
        )

        card.addView(
            ingredients
        )

        card.addView(
            nutrition
        )

        card.addView(
            time
        )

        card.addView(
            reason
        )

        card.addView(
            preparation
        )

        recommendationsContainer.addView(
            card
        )
    }
}