package com.nutrifit.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class FoodHistoryEntry(
    val id: Long,
    val foodName: String,
    val quantityGrams: Double,
    val calories: Double,
    val protein: Double,
    val carbs: Double,
    val fat: Double,
    val timestamp: Long
)

object NutritionTracker {

    private const val PREF_NAME =
        "NutriFitDailyNutrition"

    private const val HISTORY_PREF_NAME =
        "NutriFitFoodHistory"

    private const val KEY_DATE =
        "date"

    private const val KEY_CALORIES =
        "calories"

    private const val KEY_PROTEIN =
        "protein"

    private const val KEY_CARBS =
        "carbs"

    private const val KEY_FAT =
        "fat"

    private const val KEY_HISTORY =
        "food_history"

    private fun getToday(): String {

        return SimpleDateFormat(
            "yyyy-MM-dd",
            Locale.getDefault()
        ).format(Date())
    }

    private fun getPreferences(
        context: Context
    ) =
        context.getSharedPreferences(
            PREF_NAME,
            Context.MODE_PRIVATE
        )

    private fun getHistoryPreferences(
        context: Context
    ) =
        context.getSharedPreferences(
            HISTORY_PREF_NAME,
            Context.MODE_PRIVATE
        )

    private fun resetIfNewDay(
        context: Context
    ) {

        val preferences =
            getPreferences(context)

        val savedDate =
            preferences.getString(
                KEY_DATE,
                ""
            )

        if (savedDate != getToday()) {

            preferences.edit()
                .putString(
                    KEY_DATE,
                    getToday()
                )
                .putFloat(
                    KEY_CALORIES,
                    0f
                )
                .putFloat(
                    KEY_PROTEIN,
                    0f
                )
                .putFloat(
                    KEY_CARBS,
                    0f
                )
                .putFloat(
                    KEY_FAT,
                    0f
                )
                .apply()
        }
    }

    /*
     * Existing version kept for compatibility.
     *
     * This means the rest of the app will continue
     * compiling even before ManualFoodActivity
     * is updated to send food-history information.
     */
    fun addFood(
        context: Context,
        calories: Double,
        protein: Double,
        carbs: Double,
        fat: Double
    ) {

        addToDailyNutrition(
            context = context,
            calories = calories,
            protein = protein,
            carbs = carbs,
            fat = fat
        )
    }

    /*
     * New version.
     *
     * This updates today's nutrition AND stores
     * the food as a history record.
     */
    fun addFood(
        context: Context,
        foodName: String,
        quantityGrams: Double,
        calories: Double,
        protein: Double,
        carbs: Double,
        fat: Double
    ) {

        addToDailyNutrition(
            context = context,
            calories = calories,
            protein = protein,
            carbs = carbs,
            fat = fat
        )

        addToHistory(
            context = context,
            foodName = foodName,
            quantityGrams = quantityGrams,
            calories = calories,
            protein = protein,
            carbs = carbs,
            fat = fat
        )
    }

    private fun addToDailyNutrition(
        context: Context,
        calories: Double,
        protein: Double,
        carbs: Double,
        fat: Double
    ) {

        resetIfNewDay(context)

        val preferences =
            getPreferences(context)

        val currentCalories =
            preferences.getFloat(
                KEY_CALORIES,
                0f
            )

        val currentProtein =
            preferences.getFloat(
                KEY_PROTEIN,
                0f
            )

        val currentCarbs =
            preferences.getFloat(
                KEY_CARBS,
                0f
            )

        val currentFat =
            preferences.getFloat(
                KEY_FAT,
                0f
            )

        preferences.edit()
            .putFloat(
                KEY_CALORIES,
                currentCalories +
                        calories.toFloat()
            )
            .putFloat(
                KEY_PROTEIN,
                currentProtein +
                        protein.toFloat()
            )
            .putFloat(
                KEY_CARBS,
                currentCarbs +
                        carbs.toFloat()
            )
            .putFloat(
                KEY_FAT,
                currentFat +
                        fat.toFloat()
            )
            .apply()
    }

    private fun addToHistory(
        context: Context,
        foodName: String,
        quantityGrams: Double,
        calories: Double,
        protein: Double,
        carbs: Double,
        fat: Double
    ) {

        val preferences =
            getHistoryPreferences(context)

        val historyString =
            preferences.getString(
                KEY_HISTORY,
                "[]"
            ) ?: "[]"

        val historyArray =
            try {
                JSONArray(historyString)
            } catch (
                exception: Exception
            ) {
                JSONArray()
            }

        val timestamp =
            System.currentTimeMillis()

        val foodObject =
            JSONObject().apply {

                put(
                    "id",
                    timestamp
                )

                put(
                    "foodName",
                    foodName
                )

                put(
                    "quantityGrams",
                    quantityGrams
                )

                put(
                    "calories",
                    calories
                )

                put(
                    "protein",
                    protein
                )

                put(
                    "carbs",
                    carbs
                )

                put(
                    "fat",
                    fat
                )

                put(
                    "timestamp",
                    timestamp
                )
            }

        historyArray.put(
            foodObject
        )

        preferences.edit()
            .putString(
                KEY_HISTORY,
                historyArray.toString()
            )
            .apply()
    }

    fun getHistory(
        context: Context
    ): List<FoodHistoryEntry> {

        val preferences =
            getHistoryPreferences(context)

        val historyString =
            preferences.getString(
                KEY_HISTORY,
                "[]"
            ) ?: "[]"

        val historyEntries =
            mutableListOf<FoodHistoryEntry>()

        try {

            val historyArray =
                JSONArray(
                    historyString
                )

            for (
            index in 0 until
                    historyArray.length()
            ) {

                val foodObject =
                    historyArray
                        .getJSONObject(
                            index
                        )

                val entry =
                    FoodHistoryEntry(
                        id =
                            foodObject.optLong(
                                "id"
                            ),

                        foodName =
                            foodObject.optString(
                                "foodName"
                            ),

                        quantityGrams =
                            foodObject.optDouble(
                                "quantityGrams"
                            ),

                        calories =
                            foodObject.optDouble(
                                "calories"
                            ),

                        protein =
                            foodObject.optDouble(
                                "protein"
                            ),

                        carbs =
                            foodObject.optDouble(
                                "carbs"
                            ),

                        fat =
                            foodObject.optDouble(
                                "fat"
                            ),

                        timestamp =
                            foodObject.optLong(
                                "timestamp"
                            )
                    )

                historyEntries.add(
                    entry
                )
            }

        } catch (
            exception: Exception
        ) {

            exception.printStackTrace()
        }

        /*
         * Most recently added food appears first.
         */
        return historyEntries
            .sortedByDescending {
                it.timestamp
            }
    }

    /*
     * Clears both:
     * 1. Food History
     * 2. Today's consumed nutrition totals
     *
     * Profile targets such as daily calories,
     * protein, carbs, fat, BMR and TDEE are
     * stored separately and are NOT affected.
     */
    fun clearHistory(
        context: Context
    ) {

        // Clear all food history
        getHistoryPreferences(
            context
        )
            .edit()
            .remove(
                KEY_HISTORY
            )
            .apply()

        // Reset today's nutrition totals
        getPreferences(
            context
        )
            .edit()
            .putString(
                KEY_DATE,
                getToday()
            )
            .putFloat(
                KEY_CALORIES,
                0f
            )
            .putFloat(
                KEY_PROTEIN,
                0f
            )
            .putFloat(
                KEY_CARBS,
                0f
            )
            .putFloat(
                KEY_FAT,
                0f
            )
            .apply()
    }

    fun getCalories(
        context: Context
    ): Float {

        resetIfNewDay(
            context
        )

        return getPreferences(
            context
        ).getFloat(
            KEY_CALORIES,
            0f
        )
    }

    fun getProtein(
        context: Context
    ): Float {

        resetIfNewDay(
            context
        )

        return getPreferences(
            context
        ).getFloat(
            KEY_PROTEIN,
            0f
        )
    }

    fun getCarbs(
        context: Context
    ): Float {

        resetIfNewDay(
            context
        )

        return getPreferences(
            context
        ).getFloat(
            KEY_CARBS,
            0f
        )
    }

    fun getFat(
        context: Context
    ): Float {

        resetIfNewDay(
            context
        )

        return getPreferences(
            context
        ).getFloat(
            KEY_FAT,
            0f
        )
    }
}