package com.nutrifit.app

import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import kotlin.math.max
import kotlin.math.roundToInt

class NutritionActivity : AppCompatActivity() {

    private lateinit var tvDailyCalories: TextView
    private lateinit var tvCaloriesRemaining: TextView
    private lateinit var tvProteinTarget: TextView
    private lateinit var tvCarbsTarget: TextView
    private lateinit var tvFatTarget: TextView
    private lateinit var tvBmr: TextView
    private lateinit var tvTdee: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_nutrition)

        // Connect XML views
        tvDailyCalories = findViewById(R.id.tvDailyCalories)
        tvCaloriesRemaining = findViewById(R.id.tvCaloriesRemaining)
        tvProteinTarget = findViewById(R.id.tvProteinTarget)
        tvCarbsTarget = findViewById(R.id.tvCarbsTarget)
        tvFatTarget = findViewById(R.id.tvFatTarget)
        tvBmr = findViewById(R.id.tvBmr)
        tvTdee = findViewById(R.id.tvTdee)
    }

    override fun onResume() {
        super.onResume()
        loadNutritionTargets()
    }

    private fun loadNutritionTargets() {

        val preferences = getSharedPreferences(
            "NutriFitProfile",
            MODE_PRIVATE
        )

        val dailyCalories = preferences.getFloat(
            "dailyCalories",
            0f
        )

        val proteinTarget = preferences.getFloat(
            "proteinGrams",
            0f
        )

        val carbsTarget = preferences.getFloat(
            "carbsGrams",
            0f
        )

        val fatTarget = preferences.getFloat(
            "fatGrams",
            0f
        )

        val bmr = preferences.getFloat(
            "bmr",
            0f
        )

        val tdee = preferences.getFloat(
            "tdee",
            0f
        )

        // Get today's consumed nutrition
        val consumedCalories = NutritionTracker.getCalories(this)

        val consumedProtein = NutritionTracker.getProtein(this)

        val consumedCarbs = NutritionTracker.getCarbs(this)

        val consumedFat = NutritionTracker.getFat(this)

        // Calculate remaining calories
        val remainingCalories = max(
            0f,
            dailyCalories - consumedCalories
        )

        // Display calories
        tvDailyCalories.text =
            "${consumedCalories.roundToInt()} / ${dailyCalories.roundToInt()} kcal"

        tvCaloriesRemaining.text =
            "Remaining: ${remainingCalories.roundToInt()} kcal"

        // Display macronutrients
        tvProteinTarget.text =
            "${consumedProtein.roundToInt()} / ${proteinTarget.roundToInt()} g"

        tvCarbsTarget.text =
            "${consumedCarbs.roundToInt()} / ${carbsTarget.roundToInt()} g"

        tvFatTarget.text =
            "${consumedFat.roundToInt()} / ${fatTarget.roundToInt()} g"

        // Display metabolic information
        tvBmr.text =
            "BMR: ${bmr.roundToInt()} kcal/day"

        tvTdee.text =
            "TDEE: ${tdee.roundToInt()} kcal/day"
    }
}