package com.nutrifit.app

object BarcodeDatabase {

    /*
     * Demo barcode mappings for testing the NutriFit scanner.
     *
     * These are application-defined test mappings.
     * They are NOT intended to represent the real barcodes
     * of commercial products.
     */

    private val barcodeToFood = mapOf(
        "2000000000011" to "Chicken Breast",
        "2000000000028" to "Egg",
        "2000000000035" to "Rice",
        "2000000000042" to "Brown Rice",
        "2000000000059" to "Oats",
        "2000000000066" to "Banana",
        "2000000000073" to "Apple",
        "2000000000080" to "Broccoli",
        "2000000000097" to "Milk",
        "2000000000103" to "Greek Yogurt",
        "2000000000110" to "Almonds"
    )

    fun getFoodName(barcode: String): String? {
        return barcodeToFood[barcode.trim()]
    }

    fun getFood(barcode: String): Food? {
        val foodName = getFoodName(barcode) ?: return null
        return FoodDatabase.getFood(foodName)
    }
}